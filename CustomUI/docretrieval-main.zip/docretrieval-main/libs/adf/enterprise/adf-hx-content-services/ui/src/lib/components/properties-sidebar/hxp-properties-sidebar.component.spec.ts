/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HxpPropertiesSidebarComponent } from './hxp-properties-sidebar.component';
import { provideAdfEnterpriseAdfHxContentServicesServices } from '@alfresco/adf-hx-content-services/services';
import { BehaviorSubject } from 'rxjs';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { NoopTranslateModule } from '@alfresco/adf-core';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { mockHxcsJsClientConfigurationService } from '@alfresco/adf-hx-content-services/api';
import { FeaturesServiceToken } from '@alfresco/adf-core/feature-flags';
import { By } from '@angular/platform-browser';

@Component({
    selector: 'hxp-properties-sidebar-legacy',
    template: '<div data-testid="legacy-sidebar">Legacy Sidebar</div>',
    standalone: true,
})
class MockHxpPropertiesSidebarLegacyComponent {
    @Input() document?: Document;
    @Input() editable = true;
    @Output() closePropertySidebar = new EventEmitter<void>();

    triggerClose() {
        this.closePropertySidebar.emit();
    }
}

@Component({
    selector: 'hxp-metadata-sidebar',
    template: '<div data-testid="metadata-sidebar">Metadata Sidebar</div>',
    standalone: true,
})
class MockHxpMetadataSidebarComponent {
    @Input() document?: Document;
    @Input() editable = true;
    @Output() closePropertySidebar = new EventEmitter<void>();

    triggerClose() {
        this.closePropertySidebar.emit();
    }
}

describe('HxpPropertiesSidebarComponent', () => {
    let component: HxpPropertiesSidebarComponent;
    let fixture: ComponentFixture<HxpPropertiesSidebarComponent>;
    let mockDocument: Document;
    let mockFeaturesService: { isOn$: jest.Mock };
    let featureFlagSubject: BehaviorSubject<boolean>;

    beforeEach(() => {
        featureFlagSubject = new BehaviorSubject<boolean>(false);

        mockFeaturesService = {
            isOn$: jest.fn().mockReturnValue(featureFlagSubject),
        };

        TestBed.configureTestingModule({
            imports: [NoopAnimationsModule, NoopTranslateModule, MatSnackBarModule, HxpPropertiesSidebarComponent],
            providers: [
                provideAdfEnterpriseAdfHxContentServicesServices(),
                mockHxcsJsClientConfigurationService,
                { provide: FeaturesServiceToken, useValue: mockFeaturesService },
            ],
        });

        TestBed.overrideComponent(HxpPropertiesSidebarComponent, {
            set: {
                imports: [MockHxpPropertiesSidebarLegacyComponent, MockHxpMetadataSidebarComponent],
            },
        });

        mockDocument = {
            sys_id: '123',
            sys_primaryType: 'SysFile',
        } as Document;

        fixture = TestBed.createComponent(HxpPropertiesSidebarComponent);
        component = fixture.componentInstance;
        component.document = mockDocument;
    });

    describe('Feature Flag', () => {
        it('should render metadata sidebar when feature flag is enabled', () => {
            featureFlagSubject.next(true);
            fixture.detectChanges();

            const metadataSidebar = fixture.debugElement.query(By.css('[data-testid="metadata-sidebar"]'));
            const legacySidebar = fixture.debugElement.query(By.css('[data-testid="legacy-sidebar"]'));

            expect(metadataSidebar).toBeTruthy();
            expect(legacySidebar).toBeFalsy();
        });

        it('should render legacy sidebar when feature flag is disabled', () => {
            featureFlagSubject.next(false);
            fixture.detectChanges();

            const metadataSidebar = fixture.debugElement.query(By.css('[data-testid="metadata-sidebar"]'));
            const legacySidebar = fixture.debugElement.query(By.css('[data-testid="legacy-sidebar"]'));

            expect(metadataSidebar).toBeFalsy();
            expect(legacySidebar).toBeTruthy();
        });
    });

    describe('Component', () => {
        it('should pass document input to child components', () => {
            featureFlagSubject.next(false);
            fixture.detectChanges();

            const legacySidebarComponent = fixture.debugElement.query(By.directive(MockHxpPropertiesSidebarLegacyComponent));
            expect(legacySidebarComponent.componentInstance.document).toBe(mockDocument);
        });

        it('should pass editable input to child components', () => {
            component.editable = false;
            featureFlagSubject.next(false);
            fixture.detectChanges();

            const legacySidebarComponent = fixture.debugElement.query(By.directive(MockHxpPropertiesSidebarLegacyComponent));
            expect(legacySidebarComponent.componentInstance.editable).toBe(false);
        });

        it('should emit closePropertySidebar event when onClosePropertySidebar is called', () => {
            jest.spyOn(component.closePropertySidebar, 'emit');

            (component as any).onClosePropertySidebar();

            expect(component.closePropertySidebar.emit).toHaveBeenCalledWith();
        });
    });
});
