/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { CardViewComponent, CardViewItem } from '@alfresco/adf-core';
import { Attribute, Component, EventEmitter, Input, Output } from '@angular/core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatButtonModule } from '@angular/material/button';
import { TranslatePipe } from '@ngx-translate/core';

/**
 * Component presents document properties viewer container.
 *
 * To use the `MetadataSidebarContentComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { MetadataSidebarContentComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         MetadataSidebarContentComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-metadata-sidebar-content
 *    [document]="document"
 *    [editable]="editable"
 *    [copyToClipboardAction]="copyToClipboardAction"
 *    [displayEmpty]="displayEmpty"
 *    [useChipsForMultiValueProperty]="useChipsForMultiValueProperty"
 *    [displayLabelForChips]="true">
 * </hxp-metadata-sidebar-content>
 */
@Component({
    selector: 'hxp-metadata-sidebar-content',
    templateUrl: './metadata-sidebar-content.component.html',
    styleUrls: ['./metadata-sidebar-content.component.scss'],
    standalone: true,
    imports: [MatExpansionModule, CardViewComponent, MatButtonModule, TranslatePipe],
})
export class MetadataSidebarContentComponent {
    /**
     * The document to display the properties for.
     * @type {Document}
     * @required
     */
    @Input()
    document: Document | undefined;

    /**
     * The properties to display in the card view.
     * @type {CardViewItem[]}
     * @default []
     *
     * ```ts
     * export interface CardViewItem {
     *      label: string;
     *      value: any;
     *      key: string;
     *      default?: any;
     *      type: string;
     *      displayValue: any;
     *      editable?: boolean;
     *      icon?: string;
     * }
     * ```
     *
     */
    @Input()
    properties: CardViewItem[] = [];

    /**
     * Toggles whether or not to enable copy to clipboard action.
     * @type {boolean}
     * @default true
     */
    @Input()
    copyToClipboardAction = true;

    /**
     * Toggles whether to display empty values in the card view.
     * @type {boolean}
     * @default false
     */
    @Input()
    displayEmpty = true;

    /**
     * Toggles whether the edit button should be shown
     * @type {boolean}
     * @default false
     */
    @Input()
    editable = false;

    /**
     * Toggles whether or not to enable chips for multivalued properties.
     * @type {boolean}
     * @default true
     */
    @Input()
    useChipsForMultiValueProperty = true;

    /**
     * Toggles whether or not to display label for multivalued properties.
     * @type {boolean}
     * @default false
     */
    @Input()
    displayLabelForChips = false;

    @Output()
    propertyUpdateRequest: EventEmitter<boolean> = new EventEmitter<boolean>();

    protected readonly multiValueSeparator = ', ';

    constructor(
        /**
         * An attribute representing a text to display in the header. Can be a key to translate.
         * @type {boolean}
         * @default false
         */
        @Attribute('headerText')
        public headerText = 'CORE.METADATA.BASIC.HEADER'
    ) {}
}
