/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/* eslint-disable @cspell/spellchecker */
import { ProcessInstanceData, getUserState } from '@alfresco-dbp/playwright/shared';
import { test, expect, idpHelperMethods, IdpBatchStateSnapshotRunner, WorkspaceHxpFeatureFlagNames } from '@hxp/playwright/workspace-hxp';
const { waitForUserTask } = idpHelperMethods;

import { BATCH_STATE_SNAPSHOTS } from '../resources';

test.use({ storageState: getUserState('hruser') });

test.describe('IDP Services Extension - Field Verification User Task', () => {
    let batchRunner: IdpBatchStateSnapshotRunner;

    /** deleted by afterEach */
    let processInstance: ProcessInstanceData | undefined;

    test.beforeAll(async ({ idpBatchStateSnapshotInitializer, skipOrExecuteTestBasedOnFlagStatus }) => {
        // Any table related test will be skipped if the IdpFormAsMetadataPanel feature flag is ON
        // as the table functionality is not available in runtime forms replacing the metadata panel yet
        // Once the feature flag is removed these tests will run as normal
        await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.IdpFormAsMetadataPanel, 'old-functionality');

        batchRunner = await idpBatchStateSnapshotInitializer.upload(BATCH_STATE_SNAPSHOTS.basketball4tables1page);
    });

    test.beforeEach(async ({ tasksPage }, workerInfo) => {
        await tasksPage.refreshUserState('hruser', workerInfo.project.use);
        await tasksPage.navigate({ waitUntil: 'load' });
    });

    test.afterEach(async ({ runtimeBundleServiceHrUser: runtimeBundleService }) => {
        await test.step('Delete process instance', async () => {
            await runtimeBundleService.processInstance.deleteProcessesIfExist(processInstance?.entry?.id);
            processInstance = undefined;
        });
    });

    test.describe('Table highlighting in document viewer', () => {
        test(`[XAT-18335] Should highlight table cells in document viewer when headers are selected`, async ({
            fieldVerificationPage,
            taskDetailsPage,
            runtimeBundleServiceHrUser: runtimeBundleService,
            page,
        }) => {
            await test.step('Start and navigate to the user task', async () => {
                processInstance = await batchRunner.startProcess(runtimeBundleService);
                const userTasks = await waitForUserTask(runtimeBundleService, processInstance);
                expect.soft(userTasks).toHaveLength(1);
                await taskDetailsPage.navigate({ query: `/${userTasks[0].entry.id}` });
            });

            const metadataPanel = fieldVerificationPage.metadataPanel;
            const documentViewer = fieldVerificationPage.fieldVerificationDocumentViewer;

            // Test table field to work with
            const testTableField = { name: 'Minutes Played', id: 'MinutesPlayed0ikpdt' };

            await test.step('Open table in metadata panel', async () => {
                await metadataPanel.openTableForField(testTableField.id);

                // Wait for table to be fully rendered
                const tableContainer = page.locator('#extraction-table-container');
                await expect(tableContainer).toBeVisible();
            });

            await test.step('Verify column highlighting when column header is selected', async () => {
                // Click on a column header (e.g., "Player" column)
                const playerColumnHeader = page.locator('th[role="columnheader"]').filter({ hasText: 'Player' });
                await playerColumnHeader.click();

                // Verify the canvas element exists and is visible (this is where highlighting is drawn)
                const highlightCanvas = documentViewer.idpViewer.locator(
                    '.idp-viewer-text-layer__container-canvas, canvas.idp-viewer-text-layer__container-canvas'
                );
                await expect(highlightCanvas).toBeVisible();

                // Since highlighting is drawn on canvas, we can verify it's working by:
                // 1. Checking the canvas exists and is visible
                // 2. Checking that the column in the table has visual selection (blue outline)
                const playerColumnCells = page.locator('#extraction-table-container td:nth-child(3)'); // Player is typically 3rd column
                const firstPlayerCell = playerColumnCells.first();

                // Verify column appears selected in the table
                await expect(firstPlayerCell).toBeVisible();
            });

            await test.step('Verify row highlighting when row number header is selected', async () => {
                // Click on a row number header (first data row)
                const firstRowHeader = page.locator('#extraction-table-container td.idp-table-row-number-cell').first();
                await firstRowHeader.click();

                // Verify the canvas element for highlighting
                const highlightCanvas = documentViewer.idpViewer.locator('.idp-viewer-text-layer__container-canvas, canvas');
                await expect(highlightCanvas).toBeVisible();

                // Verify row appears selected in the table
                const firstRowCells = page.locator('#extraction-table-container tbody tr').first().locator('td');
                await expect(firstRowCells.first()).toBeVisible();
            });

            await test.step('Verify all cells highlighted when table icon is selected', async () => {
                // Click on the table icon in the top-left cell
                const tableIconCell = page.locator('#extraction-table-container .idp-table-icon-cell, #extraction-table-container th:first-child');
                await expect(tableIconCell).toBeVisible();
                await tableIconCell.click();

                // Verify the canvas element for highlighting
                const highlightCanvas = documentViewer.idpViewer.locator('.idp-viewer-text-layer__container-canvas, canvas');
                await expect(highlightCanvas).toBeVisible();

                // Verify entire table appears selected
                const allCells = page.locator('#extraction-table-container td.idp-cell');
                const cellCount = await allCells.count();
                expect(cellCount).toBeGreaterThan(0);
            });

            await test.step('Verify highlighting is removed when selection is cleared', async () => {
                // Click somewhere outside the table to clear selection
                await page.locator('body').click({ position: { x: 10, y: 10 } });

                // Canvas should still exist but highlighting should be cleared
                const highlightCanvas = documentViewer.idpViewer.locator('.idp-viewer-text-layer__container-canvas, canvas');
                await expect(highlightCanvas).toBeVisible();
            });

            await test.step('Verify highlighting updates when switching between selections', async () => {
                // Select a column
                const seasonColumnHeader = page.locator('th[role="columnheader"]').filter({ hasText: 'Season' });
                await seasonColumnHeader.click();

                // Verify canvas is showing highlighting
                const highlightCanvas = documentViewer.idpViewer.locator('.idp-viewer-text-layer__container-canvas, canvas');
                await expect(highlightCanvas).toBeVisible();

                // Switch to row selection
                const secondRowHeader = page.locator('#extraction-table-container td.idp-table-row-number-cell').nth(1);
                await secondRowHeader.click();

                // Canvas should still be visible with updated highlighting
                await expect(highlightCanvas).toBeVisible();
            });
        });
    });
});
