/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { MetadataSidebarContentComponent } from './metadata-sidebar-content.component';
import { CardViewItem, NoopTranslateModule, CardViewComponent } from '@alfresco/adf-core';

@Component({
    // eslint-disable-next-line @angular-eslint/component-selector
    selector: 'adf-card-view',
    template: `
        <div class="mock-card-view" [attr.data-display-empty]="displayEmpty ? 'true' : 'false'">
            <ng-container *ngFor="let property of properties">
                <div class="adf-property" [attr.data-automation-id]="'header-' + property.key">
                    <div class="adf-property-inner">
                        <ng-container *ngIf="shouldShowProperty(property)">
                            <label class="mock-card-view-label" [attr.data-automation-id]="'card-textitem-label-' + property.key">
                                {{ property.label }}
                            </label>
                            <span class="mock-card-view-value">{{ property.displayValue }}</span>
                        </ng-container>
                    </div>
                </div>
            </ng-container>
        </div>
    `,
    standalone: true,
    imports: [CommonModule],
})
class MockCardViewComponent {
    @Input() properties: CardViewItem[] = [];
    @Input() editable = false;
    @Input() displayEmpty = true;
    @Input() copyToClipboardAction = true;
    @Input() useChipsForMultiValueProperty = false;
    @Input() displayLabelForChips = false;
    @Input() multiValueSeparator?: string;

    shouldShowProperty(property: CardViewItem): boolean {
        if (this.displayEmpty) {
            return true;
        }
        const valueToCheck = property.displayValue ?? property.value;
        return valueToCheck !== undefined && valueToCheck !== null && valueToCheck !== '';
    }
}

@Component({
    template: `<hxp-metadata-sidebar-content headerText="CUSTOM.HEADER" [properties]="properties" />`,
    imports: [MetadataSidebarContentComponent],
    standalone: true,
})
class HostCustomHeaderComponent {
    properties = [{ label: 'Title', value: 'My Document', key: 'sys_title', type: 'text', displayValue: 'My Document' } as CardViewItem];
}

@Component({
    template: `<hxp-metadata-sidebar-content [displayEmpty]="displayEmpty" [properties]="properties" />`,
    imports: [MetadataSidebarContentComponent],
    standalone: true,
})
class HostDisplayEmptyComponent {
    displayEmpty = false;
    properties = [{ label: 'Custom Field', value: '', key: 'custom_property', type: 'text', displayValue: '' } as CardViewItem];
}

@Component({
    template: `<hxp-metadata-sidebar-content [properties]="properties" />`,
    imports: [MetadataSidebarContentComponent],
    standalone: true,
})
class HostDefaultDisplayEmptyComponent {
    properties = [{ label: 'Default Empty Field', value: '', key: 'default_property', type: 'text', displayValue: '' } as CardViewItem];
}

describe('MetadataSidebarContentComponent', () => {
    let fixture: ComponentFixture<MetadataSidebarContentComponent>;
    let component: MetadataSidebarContentComponent;

    const mockProperties: CardViewItem[] = [
        {
            label: 'Title',
            value: 'My Document',
            key: 'sys_title',
            type: 'text',
            displayValue: 'My Document',
        },
        {
            label: 'Description',
            value: 'A test document',
            key: 'sys_description',
            type: 'text',
            displayValue: 'A test document',
        },
    ];

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [
                MetadataSidebarContentComponent,
                HostCustomHeaderComponent,
                HostDisplayEmptyComponent,
                HostDefaultDisplayEmptyComponent,
                NoopTranslateModule,
            ],
        })
            .overrideComponent(MetadataSidebarContentComponent, {
                remove: {
                    imports: [CardViewComponent],
                },
                add: {
                    imports: [MockCardViewComponent],
                },
            })
            .compileComponents();

        fixture = TestBed.createComponent(MetadataSidebarContentComponent);
        component = fixture.componentInstance;
        component.properties = mockProperties;
    });

    it('should render adf-card-view with the correct properties', () => {
        fixture.detectChanges();

        const cardViewDebugElement = fixture.debugElement.query(By.directive(MockCardViewComponent));

        expect(cardViewDebugElement).toBeTruthy();

        const cardViewInstance = cardViewDebugElement.componentInstance as MockCardViewComponent;

        expect(cardViewInstance.properties).toEqual(mockProperties);
    });

    it('should not render adf-card-view if properties are empty', () => {
        component.properties = [];
        fixture.detectChanges();

        const cardViewDebugElement = fixture.debugElement.query(By.directive(MockCardViewComponent));

        expect(cardViewDebugElement).toBeFalsy();
    });

    it('should render custom headerText when attribute provided', () => {
        const hostFixture = TestBed.createComponent(HostCustomHeaderComponent);
        hostFixture.detectChanges();

        const headerEl = hostFixture.debugElement.query(By.css('.hxp-metadata-properties-title'));
        expect(headerEl).toBeTruthy();
        expect(headerEl.nativeElement.textContent.trim()).toBe('CUSTOM.HEADER');
    });

    it('should render properties with empty values when displayEmpty is true', () => {
        const hostFixture = TestBed.createComponent(HostDisplayEmptyComponent);
        hostFixture.detectChanges();

        const missingWhenHidden = hostFixture.debugElement.query(By.css('[data-automation-id="header-custom_property"] .mock-card-view-label'));
        expect(missingWhenHidden).toBeFalsy();

        hostFixture.componentInstance.displayEmpty = true;
        hostFixture.detectChanges();

        const renderedWhenVisible = hostFixture.debugElement.query(By.css('[data-automation-id="header-custom_property"] .mock-card-view-label'));
        expect(renderedWhenVisible).toBeTruthy();
        expect(renderedWhenVisible.nativeElement.textContent).toContain('Custom Field');
    });

    it('should display empty properties by default', () => {
        const hostFixture = TestBed.createComponent(HostDefaultDisplayEmptyComponent);
        hostFixture.detectChanges();

        const cardViewDebugElement = hostFixture.debugElement.query(By.directive(MockCardViewComponent));
        expect(cardViewDebugElement).toBeTruthy();

        const propertyHeader = cardViewDebugElement.nativeElement.querySelector('[data-automation-id="header-default_property"]');
        expect(propertyHeader).toBeTruthy();
        expect(propertyHeader.textContent).toContain('Default Empty Field');
    });
});
