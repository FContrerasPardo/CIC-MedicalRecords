/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { DefaultStatusSnackBarIcon } from '@alfresco/adf-hx-content-services/api';
import { DownloadStatus } from '../models/download-status.enum';

export const downloadSnackBarTypes: Record<DownloadStatus, DefaultStatusSnackBarIcon> = {
    [DownloadStatus.REQUEST]: 'info',
    [DownloadStatus.SUCCESS]: 'done',
    [DownloadStatus.ERROR]: 'error',
};
