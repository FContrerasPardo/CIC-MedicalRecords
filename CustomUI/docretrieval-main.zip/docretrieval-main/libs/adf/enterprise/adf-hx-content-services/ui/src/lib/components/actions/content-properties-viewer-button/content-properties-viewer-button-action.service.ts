/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { ActionContext, DocumentActionService, DocumentPermissions, hasPermission, SidebarService } from '@alfresco/adf-hx-content-services/services';
import { inject, Injectable } from '@angular/core';

@Injectable()
export class ContentPropertyViewerActionService extends DocumentActionService {
    private sidebarService = inject(SidebarService);

    constructor() {
        super();
    }

    isAvailable(context: ActionContext): boolean {
        return context.documents?.length === 1 && hasPermission(context.documents[0], DocumentPermissions.READ);
    }

    execute(): void {
        this.sidebarService.togglePanel('property');
    }
}
