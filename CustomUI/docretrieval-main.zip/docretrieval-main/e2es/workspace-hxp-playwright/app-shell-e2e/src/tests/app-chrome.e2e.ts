/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { getDeployedApp, getUserState, StringHelper, TestFlags } from '@alfresco-dbp/playwright/shared';
import { expect, test, WorkspaceHxpFeatureFlagNames } from '@hxp/playwright/workspace-hxp';

test.use({ storageState: getUserState('hruser') });

test.describe('Workspace-HxP Header functionality', () => {
    test(`${TestFlags.UnderFF} [XAT-18237] Verify the deployed app is selected`, async ({
        contentBrowserPage,
        skipOrExecuteTestBasedOnFlagStatus,
    }, workerInfo) => {
        await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.CicWorkspaceSatoriApplicationChrome, 'new-functionality');

        const deployedApp = getDeployedApp(workerInfo.project.use).appName;
        const defaultApp = StringHelper.capitalize(deployedApp).replaceAll('-', ' ');

        await contentBrowserPage.navigate();
        await expect.soft(contentBrowserPage.hxpApplicationChromeComponent.activeApplication).toHaveText(defaultApp);
    });
});
