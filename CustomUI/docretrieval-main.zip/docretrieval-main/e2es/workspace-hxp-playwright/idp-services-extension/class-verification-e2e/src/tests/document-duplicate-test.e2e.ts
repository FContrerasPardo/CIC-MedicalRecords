/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { ProcessInstanceData, RequestResponse, getUserState } from '@alfresco-dbp/playwright/shared';
import { test, expect, idpHelperMethods, IdpBatchStateSnapshotRunner } from '@hxp/playwright/workspace-hxp';
import { BATCH_STATE_SNAPSHOTS } from '../resources';
const { waitForUserTask, refreshUserState } = idpHelperMethods;

test.use({ storageState: getUserState('hruser') });

test.describe('Workspace IDP Tests - Copy pages and document tests', () => {
    let processInstance: ProcessInstanceData | RequestResponse | undefined;
    let batchRunner: IdpBatchStateSnapshotRunner;

    test.beforeAll(async ({ idpBatchStateSnapshotInitializer }) => {
        batchRunner = await idpBatchStateSnapshotInitializer.upload(BATCH_STATE_SNAPSHOTS.resume1);
    });

    test.beforeEach(async ({ tasksPage }, workerInfo) => {
        await refreshUserState(tasksPage, workerInfo);
    });

    test.afterEach(async ({ runtimeBundleServiceHrUser: runtimeBundleService }) => {
        await runtimeBundleService.processInstance.deleteProcessesIfExist(processInstance?.entry?.id);
    });

    test(`[XAT-18669] Document and pages should be duplicated`, async ({
        taskDetailsPage,
        runtimeBundleServiceHrUser: runtimeBundleService,
        idpClassificationPage,
    }) => {
        processInstance = await batchRunner.startProcess(runtimeBundleService);
        const userTasks = await waitForUserTask(runtimeBundleService, processInstance);
        await taskDetailsPage.navigate({ query: `/${userTasks[0].entry.id}`, waitUntil: 'load' });

        // Copy full document with toolbar button and expect new document below.
        await idpClassificationPage.documentBrowser.sortByOption.click();
        await idpClassificationPage.overlayContainer.sortOption1.click();
        await idpClassificationPage.documentBrowser.getClass(1).getDocument(0).getRootLocator.click();
        await idpClassificationPage.floaterToolbar.copyButton.click();
        await expect(idpClassificationPage.documentBrowser.getClass(1).getDocument(1).getRootLocator).toHaveCount(1);

        // Merge documents and select then copy single page from it then expect new document below.
        await idpClassificationPage.documentBrowser
            .getClass(1)
            .getDocument(1)
            .getRootLocator.click({ modifiers: ['Shift'] });
        await idpClassificationPage.floaterToolbar.mergeButton.click();
        await expect(idpClassificationPage.documentBrowser.getClass(1).getDocument(0).getPageComponent(3).getRootLocator).toHaveCount(1);
        await idpClassificationPage.documentBrowser.getClass(1).getDocument(0).getPageComponent(2).getRootLocator.click();
        await idpClassificationPage.floaterToolbar.copyButton.click();
        await expect(idpClassificationPage.documentBrowser.getClass(1).getDocument(1).getRootLocator).toHaveCount(1);
        await expect(idpClassificationPage.documentBrowser.getClass(1).getDocument(1).getPageComponent(0).getRootLocator).toHaveCount(1);

        // Copy full document with shortcut and expect new document below.
        await idpClassificationPage.documentBrowser.getClass(1).getDocument(1).getRootLocator.click();
        await idpClassificationPage.page.keyboard.press('D');
        await expect(idpClassificationPage.documentBrowser.getClass(1).getDocument(2).getRootLocator).toHaveCount(1);
    });
});
