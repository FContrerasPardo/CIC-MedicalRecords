/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { getUserState, HXP_APPS, ProcessInstanceDataEntry, UtilRandom, files, Document } from '@alfresco-dbp/playwright/shared';
import { test, expect, ProcessManagementLabels } from '@hxp/playwright/workspace-hxp';

test.use({ storageState: getUserState('hruser') });
test.describe('File Viewer and Metadata Viewer', () => {
    const { processes } = HXP_APPS.SYS_WORKSPACE;
    const testPdfFile = files.pdfFile;
    const testTiffFile = files.tiffFile;

    let processInstance: ProcessInstanceDataEntry;
    let destinationFolder: Document;
    let destinationFolderName: string;

    test.beforeEach(async ({ processDetailsPage, hxprApi }, workerInfo) => {
        await processDetailsPage.refreshUserState('hruser', workerInfo.project.use);

        destinationFolder = await hxprApi.documentServiceApi.createFolder(`pw-e2e-folder-${UtilRandom.generateTimeStamp()}`, 'folder description');
        await hxprApi.documentServiceApi.updateIndividualPermissionDocument('hr hr', destinationFolder, 'Everything');
        destinationFolderName = destinationFolder.sys_title;
    });

    test.afterEach(async ({ runtimeBundleServiceHrUser, hxprApi }) => {
        await hxprApi.documentServiceApi.teardown();
        await runtimeBundleServiceHrUser.processInstance.deleteProcessesIfExist(processInstance.id);
    });

    test('[XAT-1180] Attached file should be visible in file and metadata viewers', async ({
        taskDetailsPage,
        processDetailsPage,
        runtimeBundleServiceHrUser,
        queryServiceHrUser,
    }) => {
        const testProcess = processes.attachLocalWithViewers;
        const { formWidgets } = testProcess.form;
        const attachFileWidget = 'Attach file';
        const attachFileButtonIdLocator = `#${formWidgets.attachFileWidgetId}`;

        ({ entry: processInstance } = await runtimeBundleServiceHrUser.processInstance.startProcess(testProcess.processDefinitionKey, {
            name: `pw-e2e-attach-file-${UtilRandom.generateTimestampWithAlphaLowerCase(3)}`,
            variables: { processContentPath: { uri: `hxpr:/path/${destinationFolderName}` } },
        }));

        await queryServiceHrUser.processInstance.waitAndGetProcessInstanceByFilters({
            filters: {
                name: processInstance.name,
            },
        });
        await processDetailsPage.navigate({ query: processInstance.id });
        await processDetailsPage.dataTable.waitForRootElement();
        await processDetailsPage.dataTable.getRowByName(testProcess.userTaskName).click();

        await taskDetailsPage.openAttachmentFormById(attachFileButtonIdLocator);
        await taskDetailsPage.attachFileDialog.attachFileFromLocal(testPdfFile.path);

        await expect
            .soft(await taskDetailsPage.taskForm.getMetadataViewerLocator(formWidgets.metadataViewerId).getByLabel('Name'))
            .toHaveValue(testPdfFile.title);
        await expect.soft(taskDetailsPage.taskForm.getFieldByLabelLocator(attachFileWidget)).toContainText(testPdfFile.title);
        await expect.soft(taskDetailsPage.taskForm.getPdfViewerControlPanelLocator(formWidgets.fileViewerId)).toBeVisible();

        await taskDetailsPage.taskForm.getPdfViewerControlPanelScaleButtonLocator(formWidgets.fileViewerId).click();

        await expect.soft(taskDetailsPage.taskForm.getPdfViewerControlPanelScaleLocator(formWidgets.fileViewerId)).toHaveText('100%');
        await expect(taskDetailsPage.taskForm.getPdfViewerDocumentLocator(formWidgets.fileViewerId)).toContainText('A sample PDF file');
    });

    test('[XAT-18243] Should be able to attach and view two Local files in two-tabs form', async ({
        taskDetailsPage,
        processDetailsPage,
        runtimeBundleServiceHrUser,
        queryServiceHrUser,
    }) => {
        const testProcess = processes.attachLocalWithViewersInTwoTabs;
        const { formWidgets: formWidgetsUpload } = testProcess.forms.uploadForm;
        const { formWidgets: formWidgetsView } = testProcess.forms.viewForm;
        const attachFile1WidgetLocator = `#table-${formWidgetsUpload.attachFile1WidgetId}`;
        const attachFile2WidgetLocator = `#table-${formWidgetsUpload.attachFile2WidgetId}`;
        const attachFile1ButtonIdLocator = `#${formWidgetsUpload.attachFile1WidgetId}`;
        const attachFile2ButtonIdLocator = `#${formWidgetsUpload.attachFile2WidgetId}`;

        ({ entry: processInstance } = await runtimeBundleServiceHrUser.processInstance.startProcess(testProcess.processDefinitionKey, {
            name: `pw-e2e-attach-file-${UtilRandom.generateTimestampWithAlphaLowerCase(3)}`,
            variables: { processContentPath: { uri: `hxpr:/path/${destinationFolderName}` } },
        }));

        await queryServiceHrUser.processInstance.waitAndGetProcessInstanceByFilters({
            filters: {
                name: processInstance.name,
            },
        });
        await processDetailsPage.navigate({ query: processInstance.id });
        await processDetailsPage.dataTable.waitForRootElement();
        await processDetailsPage.dataTable.goThroughPagesLookingForRowWithName('Attach Files');
        await processDetailsPage.dataTable.getRowByName('Attach Files').click();

        await test.step('Attach files and confirm they uploaded correctly', async () => {
            await taskDetailsPage.openAttachmentFormById(attachFile1ButtonIdLocator);
            await taskDetailsPage.attachFileDialog.attachFileFromLocal(testTiffFile.path);

            await taskDetailsPage.openAttachmentFormById(attachFile2ButtonIdLocator);
            await taskDetailsPage.attachFileDialog.attachFileFromLocal(testPdfFile.path);

            await expect.soft(taskDetailsPage.page.locator(attachFile1WidgetLocator)).toContainText(testTiffFile.title);
            await expect.soft(taskDetailsPage.page.locator(attachFile2WidgetLocator)).toContainText(testPdfFile.title);
        });

        await test.step('Complete task and open next one', async () => {
            await taskDetailsPage.taskForm.completeButtonLocator.click();
            await processDetailsPage.contentSideNavbar.navigateTo(ProcessManagementLabels.MyTasks);
            await processDetailsPage.dataTable.waitForRootElement();
            await processDetailsPage.pageLayoutHeaderComponent.refreshButton.click();
            await processDetailsPage.dataTable.goThroughPagesLookingForRowWithName(testProcess.taskFlow.userTaskView);
            await processDetailsPage.dataTable.getRowByName(testProcess.taskFlow.userTaskView).first().click();
            await taskDetailsPage.taskForm.waitForRootElement();
        });

        await test.step('Verify viewers for TIFF file', async () => {
            await expect.soft(taskDetailsPage.taskForm.getPdfViewerControlPanelScaleLocator(formWidgetsView.fileViewer1Id)).toHaveText('125%');
            await expect
                .soft(taskDetailsPage.taskForm.getMetadataViewerLocator(formWidgetsView.metadataViewer1Id).getByLabel('Name'))
                .toHaveValue(testTiffFile.title);
            await expect
                .soft(taskDetailsPage.taskForm.getMetadataViewerLocator(formWidgetsView.metadataViewer1Id).getByLabel('Title'))
                .toHaveValue(testTiffFile.title);
        });

        await test.step('Switch tab and verify viewers for PDF file', async () => {
            await taskDetailsPage.taskForm.getTabHeaderElement(testProcess.forms.viewForm.tabs.tabViewers2).click();
            await taskDetailsPage.taskForm.waitForRootElement();
            await expect.soft(taskDetailsPage.taskForm.getPdfViewerDocumentLocator(formWidgetsView.fileViewer2Id)).toContainText('A sample PDF file');
            await expect.soft(taskDetailsPage.taskForm.getPdfViewerControlPanelScaleLocator(formWidgetsView.fileViewer2Id)).toHaveText('100%');
            await expect
                .soft(taskDetailsPage.taskForm.getMetadataViewerLocator(formWidgetsView.metadataViewer2Id).getByLabel('Name'))
                .toHaveValue(testPdfFile.title);
            await expect(taskDetailsPage.taskForm.getMetadataViewerLocator(formWidgetsView.metadataViewer2Id).getByLabel('Title')).toHaveValue(
                testPdfFile.title
            );
        });
    });
});
