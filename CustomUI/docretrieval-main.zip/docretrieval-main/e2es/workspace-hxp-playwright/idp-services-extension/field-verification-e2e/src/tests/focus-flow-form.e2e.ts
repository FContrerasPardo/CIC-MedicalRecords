/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { ProcessInstanceData, RequestResponse, getUserState } from '@alfresco-dbp/playwright/shared';
import { test, expect, idpHelperMethods, IdpBatchStateSnapshotRunner, WorkspaceHxpFeatureFlagNames } from '@hxp/playwright/workspace-hxp';
const { waitForUserTask, expectFieldFocused } = idpHelperMethods;
import { BATCH_STATE_SNAPSHOTS } from '../resources';

test.use({ storageState: getUserState('hruser') });

test.describe('IDP Services Extension - Field Verification User Task', () => {
    let batchRunnerFocusFlowNeedsAttention: IdpBatchStateSnapshotRunner;
    let batchRunnerFocusFlowFormsWithTable: IdpBatchStateSnapshotRunner;
    let batchRunnerFocusFlowFormsEmptyTable: IdpBatchStateSnapshotRunner;

    /** deleted by afterEach */
    let processInstance: ProcessInstanceData | RequestResponse | undefined;

    test.beforeAll(async ({ idpBatchStateSnapshotInitializer }) => {
        batchRunnerFocusFlowNeedsAttention = await idpBatchStateSnapshotInitializer.upload(BATCH_STATE_SNAPSHOTS.focusFlowFormsNeedsAttention);
        batchRunnerFocusFlowFormsWithTable = await idpBatchStateSnapshotInitializer.upload(BATCH_STATE_SNAPSHOTS.focusFlowFormsWithTable);
        batchRunnerFocusFlowFormsEmptyTable = await idpBatchStateSnapshotInitializer.upload(BATCH_STATE_SNAPSHOTS.focusFlowFormsEmptyTable);
    });

    test.beforeEach(async ({ tasksPage }, workerInfo) => {
        await tasksPage.refreshUserState('hruser', workerInfo.project.use);
        await tasksPage.navigate({ waitUntil: 'load' });
    });

    test.afterEach(async ({ runtimeBundleServiceHrUser: runtimeBundleService }) => {
        await test.step('Delete process instance', async () => {
            await runtimeBundleService.processInstance.deleteProcessesIfExist(processInstance?.entry?.id);
            processInstance = undefined;
        });
    });

    test.describe('Custom form focus flow for Enter key when multiple fields need attention', () => {
        test(`[XAT-18439] Custom form focus flow for Enter key when multiple fields need attention`, async ({
            taskDetailsPage,
            runtimeBundleServiceHrUser: runtimeBundleService,
            page,
            skipOrExecuteTestBasedOnFlagStatus,
        }) => {
            // Test runs only when IdpFormAsMetadataPanel feature flag is ON
            await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.IdpFormAsMetadataPanel, 'new-functionality');

            // Ensure the page is ready and the task is loaded
            await test.step('Setup process and navigate to task', async () => {
                processInstance = await batchRunnerFocusFlowNeedsAttention.startProcess(runtimeBundleService);
                const userTasks = await waitForUserTask(runtimeBundleService, processInstance);
                expect.soft(userTasks).toHaveLength(1);
                await taskDetailsPage.navigate({ query: `/${userTasks[0].entry.id}` });
            });

            // Wait for the form to be loaded and create field locators
            await page.waitForSelector('.adf-cloud-form-container');
            const fields = Array.from({ length: 10 }, (_, i) => page.locator(`input[id^="idp_Field${String(i + 1).padStart(2, '0')}"]`));

            // Define the expected focus flow sequence
            const focusSequence = [
                // Field 3 should get the initial focus as it is the first field needing attention in tab order (Extraction Issue)
                { action: 'focus' as const, fieldIndex: 2, description: 'Initial focus on Field 03' },
                // Field 5 is next in the order of fields that need attention (at least 10 characters)
                { action: 'press' as const, expectedFieldIndex: 4, description: 'Enter navigates to Field 05' },
                // Field 6 is next in the order of fields that need attention (Extraction Issue)
                { action: 'press' as const, expectedFieldIndex: 5, description: 'Enter navigates to Field 06' },
                // Field 7 is next in the order of fields that need attention (No more than 2 characters)
                { action: 'press' as const, expectedFieldIndex: 6, description: 'Enter navigates to Field 07' },
                // Field 10 is next in the order of fields that need attention (Extraction Issue)
                { action: 'press' as const, expectedFieldIndex: 9, description: 'Enter navigates to Field 10' },
                // Field 5 is next in the order of fields that need attention (at least 10 characters)
                { action: 'press' as const, expectedFieldIndex: 4, description: 'Enter navigates to Field 05' },
                // Field 7 is next in the order of fields that need attention (No more than 2 characters)
                { action: 'press' as const, expectedFieldIndex: 6, description: 'Enter navigates to Field 07' },
                // Field 5 is next in the order of fields that need attention (at least 10 characters)
                { action: 'press' as const, expectedFieldIndex: 4, description: 'Enter navigates to Field 05' },
                // Field 7 is next in the order of fields that need attention (No more than 2 characters)
                { action: 'press' as const, expectedFieldIndex: 6, description: 'Enter navigates to Field 07' },
                // Field 5 is next in the order of fields that need attention (at least 10 characters)
                { action: 'press' as const, expectedFieldIndex: 4, description: 'Enter navigates to Field 05' },
                // Fill Field 5 with a 10 digit value to resolve its attention state
                { action: 'fill' as const, fieldIndex: 4, value: '1234567890', description: 'Fill Field 05 with a 10 digit value' },
                // After resolving Field 5, Enter should navigate to Field 07
                { action: 'press' as const, expectedFieldIndex: 6, description: 'Enter navigates to Field 07' },
                // Fill Field 7 with a 2 character value to resolve its attention state
                { action: 'fill' as const, fieldIndex: 6, value: 'AB', description: 'Fill Field 07 with a 2 character value' },
                // After resolving Field 7, Enter should navigate fields in order as no more fields need attention
                { action: 'press' as const, expectedFieldIndex: 7, description: 'Enter navigates to Field 08' },
                { action: 'press' as const, expectedFieldIndex: 8, description: 'Enter navigates to Field 09' },
                { action: 'press' as const, expectedFieldIndex: 9, description: 'Enter navigates to Field 10' },
                // After Field 10, focus should cycle back to Field 01
                { action: 'press' as const, expectedFieldIndex: 0, description: 'Enter navigates to Field 01' },
                // Continue cycling through fields
                { action: 'press' as const, expectedFieldIndex: 1, description: 'Enter navigates to Field 02' },
                { action: 'press' as const, expectedFieldIndex: 2, description: 'Enter navigates to Field 03' },
                { action: 'press' as const, expectedFieldIndex: 3, description: 'Enter navigates to Field 04' },
                { action: 'press' as const, expectedFieldIndex: 4, description: 'Enter navigates to Field 05' },
                { action: 'press' as const, expectedFieldIndex: 5, description: 'Enter navigates to Field 06' },
                { action: 'press' as const, expectedFieldIndex: 6, description: 'Enter navigates to Field 07' },
                { action: 'press' as const, expectedFieldIndex: 7, description: 'Enter navigates to Field 08' },
                { action: 'press' as const, expectedFieldIndex: 8, description: 'Enter navigates to Field 09' },
                { action: 'press' as const, expectedFieldIndex: 9, description: 'Enter navigates to Field 10' },
            ];

            // Execute the focus flow test
            for (const [index, step] of focusSequence.entries()) {
                await test.step(`Step ${index + 1}: ${step.description}`, async () => {
                    switch (step.action) {
                        case 'focus': {
                            await fields[step.fieldIndex].focus();
                            await expectFieldFocused(fields[step.fieldIndex], expect);

                            break;
                        }
                        case 'fill': {
                            await fields[step.fieldIndex].fill(step.value);
                            // Optionally verify the field has the expected value
                            await expect(fields[step.fieldIndex]).toHaveValue(step.value);

                            break;
                        }
                        case 'press': {
                            await page.keyboard.press('Enter');
                            if (step.expectedFieldIndex !== undefined) {
                                await expectFieldFocused(fields[step.expectedFieldIndex], expect);
                            }

                            break;
                        }
                        // No default
                    }
                });
            }
        });
        test(`[XAT-18628] Custom form focus flow with table field`, async ({
            taskDetailsPage,
            runtimeBundleServiceHrUser: runtimeBundleService,
            page,
            skipOrExecuteTestBasedOnFlagStatus,
        }) => {
            // Test runs only when IdpFormAsMetadataPanel feature flag is ON
            await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.IdpFormAsMetadataPanel, 'new-functionality');

            // Ensure the page is ready and the task is loaded
            await test.step('Setup process and navigate to task', async () => {
                processInstance = await batchRunnerFocusFlowFormsWithTable.startProcess(runtimeBundleService);
                const userTasks = await waitForUserTask(runtimeBundleService, processInstance);
                expect.soft(userTasks).toHaveLength(1);
                await taskDetailsPage.navigate({ query: `/${userTasks[0].entry.id}` });
            });

            // Wait for the form to be loaded and create field locators
            await page.waitForSelector('.adf-cloud-form-container');

            // Locator for issue count - matches either resolved or unresolved state
            const getIssueCountLocator = () => page.locator('[data-automation-id^="idp-issue-count"]').last();

            const fields = [
                page.locator('input[id^="idp_TextField01"]'),
                page.locator('input[id^="idp_TextField02"]'),
                page.locator('input[id^="idp_TextField03"]'),
                page.locator('input[id^="idp_TextField04"]'),
                page.locator('input[id^="idp_TextField05"]'),
                page.locator('input[id^="idp_TextField06"]'),
                page.locator('table input.idp-cell-edit-input').first(), // First table input cell
                page.locator('input[id^="idp_ReasoningField01"]'),
                page.locator('input[id^="idp_ReasoningField02"]'),
            ];

            // Define the expected focus flow sequence
            const focusSequence = [
                // TextField02 should get the initial focus as it is the first field needing attention in tab order (Extraction Issue)
                { action: 'focus' as const, fieldIndex: 1, description: 'Initial focus on TextField02' },
                // Verify there are 3 issues to resolve
                { action: 'verifyIssueCount' as const, expectedText: '3 issues to resolve', description: 'Verify 3 issues to resolve' },
                // TextField05 is next in the order of fields that need attention (Extraction Issue)
                { action: 'press' as const, expectedFieldIndex: 4, description: 'Enter navigates to TextField05' },
                // Verify there are 2 issues to resolve
                { action: 'verifyIssueCount' as const, expectedText: '2 issues to resolve', description: 'Verify 2 issues to resolve' },
                // ReasoningField02 is next in the order of fields that need attention (Extraction Issue)
                { action: 'press' as const, expectedFieldIndex: 8, description: 'Enter navigates to ReasoningField02' },
                // Verify there is 1 issue to resolve
                { action: 'verifyIssueCount' as const, expectedText: '1 issues to resolve', description: 'Verify 1 issue to resolve' },
                // Enter resolves ReasoningField02 attention state and shows all issues resolved
                { action: 'press' as const, expectedFieldIndex: 8, description: 'Enter resolves ReasoningField02' },
                { action: 'verifyIssueCount' as const, expectedText: 'All resolved', description: 'Verify all issues resolved' },
                // With all issues resolved, focus should cycle back to TextField01
                { action: 'press' as const, expectedFieldIndex: 0, description: 'Enter navigates to TextField01' },
                // Enter should continue cycling through fields in order, as no more fields need attention
                { action: 'press' as const, expectedFieldIndex: 1, description: 'Enter navigates to TextField02' },
                { action: 'press' as const, expectedFieldIndex: 2, description: 'Enter navigates to TextField03' },
                { action: 'press' as const, expectedFieldIndex: 3, description: 'Enter navigates to TextField04' },
                { action: 'press' as const, expectedFieldIndex: 4, description: 'Enter navigates to TextField05' },
                { action: 'press' as const, expectedFieldIndex: 5, description: 'Enter navigates to TextField06' },
                // After TextField06, Enter should focus on the Focus Flow Table Data Field and the table overlay should appear
                { action: 'press' as const, expectedFieldIndex: 6, description: 'Enter navigates to Focus Flow Table Data' },
                { action: 'verifyTableOverlay' as const, visible: true, description: 'Verify table overlay is visible' },
                // Pressing Enter should move focus to ReasoningField01 and the table overlay should disappear
                { action: 'press' as const, expectedFieldIndex: 7, description: 'Enter navigates to ReasoningField01' },
                { action: 'verifyTableOverlay' as const, visible: false, description: 'Verify table overlay is not visible' },
                { action: 'press' as const, expectedFieldIndex: 8, description: 'Enter navigates to ReasoningField02' },
                // After ReasoningField02, focus should cycle back to TextField01
                { action: 'press' as const, expectedFieldIndex: 0, description: 'Enter navigates to TextField01' },
            ];

            // Execute the focus flow test
            for (const [index, step] of focusSequence.entries()) {
                await test.step(`Step ${index + 1}: ${step.description}`, async () => {
                    switch (step.action) {
                        case 'focus': {
                            await fields[step.fieldIndex].focus();
                            await expectFieldFocused(fields[step.fieldIndex], expect);

                            break;
                        }
                        case 'press': {
                            await page.keyboard.press('Enter');
                            if (step.expectedFieldIndex !== undefined) {
                                await expectFieldFocused(fields[step.expectedFieldIndex], expect);
                            }

                            break;
                        }
                        case 'verifyTableOverlay': {
                            const tableOverlay = page.locator('hyland-idp-extraction-table');
                            await (step.visible ? await expect(tableOverlay).toBeVisible() : await expect(tableOverlay).not.toBeVisible());

                            break;
                        }
                        case 'verifyIssueCount': {
                            await expect(getIssueCountLocator()).toHaveText(step.expectedText);

                            break;
                        }
                        // No default
                    }
                });
            }
        });
        test(`[XAT-18629] Custom form focus flow with empty table field`, async ({
            taskDetailsPage,
            runtimeBundleServiceHrUser: runtimeBundleService,
            page,
            skipOrExecuteTestBasedOnFlagStatus,
        }) => {
            // Test runs only when IdpFormAsMetadataPanel feature flag is ON
            await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.IdpFormAsMetadataPanel, 'new-functionality');

            // Ensure the page is ready and the task is loaded
            await test.step('Setup process and navigate to task', async () => {
                processInstance = await batchRunnerFocusFlowFormsEmptyTable.startProcess(runtimeBundleService);
                const userTasks = await waitForUserTask(runtimeBundleService, processInstance);
                expect.soft(userTasks).toHaveLength(1);
                await taskDetailsPage.navigate({ query: `/${userTasks[0].entry.id}` });
            });

            // Wait for the form to be loaded and create field locators
            await page.waitForSelector('.adf-cloud-form-container');

            // Locator for issue count - matches either resolved or unresolved state
            const getIssueCountLocator = () => page.locator('[data-automation-id^="idp-issue-count"]').last();

            const fields = [
                page.locator('input[id^="idp_TextField01"]'),
                page.locator('input[id^="idp_TextField02"]'),
                page.locator('input[id^="idp_TextField03"]'),
                page.locator('input[id^="idp_TextField04"]'),
                page.locator('input[id^="idp_TextField05"]'),
                page.locator('input[id^="idp_TextField06"]'),
                page.locator('.hxp-table-reference-widget[id^="idp_ba17ad87"]'), // Table reference widget
                page.locator('input[id^="idp_ReasoningField01"]'),
                page.locator('input[id^="idp_ReasoningField02"]'),
            ];

            // Define the expected focus flow sequence
            const focusSequence = [
                // Verify there are 3 issues to resolve
                // TextField02 should get the initial focus as it is the first field needing attention in tab order (Extraction Issue)
                { action: 'verifyIssueCount' as const, expectedText: '3 issues to resolve', description: 'Verify 3 issues to resolve' },
                { action: 'focus' as const, fieldIndex: 1, description: 'Initial focus on TextField02' },
                // Enter should move focus to the Focus Flow Table Data Field, as the next field that needs attention
                // Verify table overlay appears with message about extraction failure
                // Verify there are 2 issues to resolve
                { action: 'press' as const, description: 'Enter navigates to Focus Flow Table Data' },
                { action: 'verifyTableOverlay' as const, visible: true, description: 'Verify table overlay is visible' },
                { action: 'verifyTableMessage' as const, description: 'Verify table extraction failure message' },
                { action: 'verifyIssueCount' as const, expectedText: '2 issues to resolve', description: 'Verify 2 issues to resolve' },
                // ReasoningField02 is next in the order of fields that need attention (Extraction Issue)
                // Verify the table overlay is not visible
                // Verify there is 1 issue to resolve
                { action: 'press' as const, expectedFieldIndex: 8, description: 'Enter navigates to ReasoningField02' },
                { action: 'verifyTableOverlay' as const, visible: false, description: 'Verify table overlay is not visible' },
                { action: 'verifyIssueCount' as const, expectedText: '1 issues to resolve', description: 'Verify 1 issue to resolve' },
                // Enter resolves ReasoningField02 attention state and shows all issues resolved
                { action: 'press' as const, expectedFieldIndex: 8, description: 'Enter resolves ReasoningField02' },
                { action: 'verifyIssueCount' as const, expectedText: 'All resolved', description: 'Verify all issues resolved' },
                // With all issues resolved, focus should cycle back to TextField01
                { action: 'press' as const, expectedFieldIndex: 0, description: 'Enter navigates to TextField01' },
            ];

            // Execute the focus flow test
            for (const [index, step] of focusSequence.entries()) {
                await test.step(`Step ${index + 1}: ${step.description}`, async () => {
                    switch (step.action) {
                        case 'focus': {
                            await fields[step.fieldIndex].focus();
                            await expectFieldFocused(fields[step.fieldIndex], expect);

                            break;
                        }
                        case 'press': {
                            await page.keyboard.press('Enter');
                            if (step.expectedFieldIndex !== undefined) {
                                await expectFieldFocused(fields[step.expectedFieldIndex], expect);
                            }

                            break;
                        }
                        case 'verifyTableOverlay': {
                            const tableOverlay = page.locator('hyland-idp-extraction-table');
                            await (step.visible ? await expect(tableOverlay).toBeVisible() : await expect(tableOverlay).not.toBeVisible());

                            break;
                        }
                        case 'verifyTableMessage': {
                            // Verify the no-data overlay message is present
                            const noDataOverlay = page.locator('.idp-no-data-overlay');
                            await expect(noDataOverlay).toBeVisible();
                            // Verify there is a message in the overlay (without checking exact text)
                            const overlayMessage = page.locator('.idp-no-data-overlay-table-message');
                            await expect(overlayMessage).toBeVisible();
                            await expect(overlayMessage).not.toBeEmpty();

                            break;
                        }
                        case 'verifyIssueCount': {
                            await expect(getIssueCountLocator()).toHaveText(step.expectedText);

                            break;
                        }
                        // No default
                    }
                });
            }
        });
    });
});
