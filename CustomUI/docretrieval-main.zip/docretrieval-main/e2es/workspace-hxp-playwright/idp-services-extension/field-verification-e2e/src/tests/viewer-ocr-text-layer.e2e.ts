/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { ProcessInstanceData, getUserState } from '@alfresco-dbp/playwright/shared';
import { test, expect, idpHelperMethods, IdpBatchStateSnapshotRunner, WorkspaceHxpFeatureFlagNames } from '@hxp/playwright/workspace-hxp';

import { BATCH_STATE_SNAPSHOTS } from '../resources';

const { dragOnCanvas, findOcrTooltip, findTooltipCoordinates, initializeTestAndNavigateToTask, validateCanvasAndGetBoundingBox, waitForImageToLoad } =
    idpHelperMethods;

test.use({ storageState: getUserState('hruser') });

test.describe('IDP Services Extension - Field Verification User Task', () => {
    let batchRunnerInvoice: IdpBatchStateSnapshotRunner;
    let batchRunnerTables: IdpBatchStateSnapshotRunner;
    let batchRunnerSmallTables: IdpBatchStateSnapshotRunner;

    /** deleted by afterEach */
    let processInstance: ProcessInstanceData | undefined;

    test.beforeAll(async ({ idpBatchStateSnapshotInitializer }) => {
        batchRunnerInvoice = await idpBatchStateSnapshotInitializer.upload(BATCH_STATE_SNAPSHOTS.invoice1);
        batchRunnerTables = await idpBatchStateSnapshotInitializer.upload(BATCH_STATE_SNAPSHOTS.basketball4tables1pageBiggerHeader);
        batchRunnerSmallTables = await idpBatchStateSnapshotInitializer.upload(BATCH_STATE_SNAPSHOTS.basketball4tables1pageSmallTables);
    });

    test.beforeEach(async ({ tasksPage }, workerInfo) => {
        await tasksPage.refreshUserState('hruser', workerInfo.project.use);
        await tasksPage.navigate({ waitUntil: 'load' });
    });

    test.afterEach(async ({ runtimeBundleServiceHrUser: runtimeBundleService }) => {
        await test.step('Delete process instance', async () => {
            await runtimeBundleService.processInstance.deleteProcessesIfExist(processInstance?.entry?.id);
            processInstance = undefined;
        });
    });

    test.describe('Rubberbanding OCR Text Layer', () => {
        test(`[XAT-18062] Rubberbanding OCR Text Layer`, async ({
            fieldVerificationPage,
            taskDetailsPage,
            runtimeBundleServiceHrUser: runtimeBundleService,
            page,
            skipOrExecuteTestBasedOnFlagStatus,
        }) => {
            // Any table related test will be skipped if the IdpFormAsMetadataPanel feature flag is ON
            // as the table functionality is not available in runtime forms replacing the metadata panel yet
            // Once the feature flag is removed these tests will run as normal
            await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.IdpFormAsMetadataPanel, 'old-functionality');

            await test.step('Start and navigate to the user task', async () => {
                processInstance = await initializeTestAndNavigateToTask(batchRunnerTables, runtimeBundleService, taskDetailsPage, page);
            });

            // Constants for test configuration
            const { canvas, boundingBox } = await validateCanvasAndGetBoundingBox(fieldVerificationPage);
            const searchAreaX = 30; // Adjust this value to move the search area right
            const searchAreaY = 20; // Adjust this value to move the search area down
            const searchArea = {
                x: boundingBox.x + searchAreaX,
                y: boundingBox.y + searchAreaY,
                width: boundingBox.width / 4,
                height: boundingBox.height / 10,
            };
            const clickAndDragDistanceX = 350; // Adjust as needed for your box width
            const clickAndDragDistanceY = 75; // Adjust as needed for your box height
            const expectedRubberbandHoverText = 'Basketball Statistics'; // Adjust this to the expected text in the OCR tooltip
            const ocrToolTip = fieldVerificationPage.fieldVerificationViewerTextLayer.ocrToolTip;
            const organizationFieldSelector = '[data-automation-id^="idp-field-Organization"]';
            const organizationField = page.locator(organizationFieldSelector);

            // Wait for the image to fully load
            await waitForImageToLoad(page, fieldVerificationPage);

            // Drag to select text
            const dragStart = { x: boundingBox.x, y: boundingBox.y };
            const dragEnd = { x: dragStart.x + clickAndDragDistanceX, y: dragStart.y + clickAndDragDistanceY };
            await dragOnCanvas(page, dragStart, dragEnd);

            // Find and store OCR value for rubberbanded text
            const { coords: rubberBandCoords, value: ocrValueRubberBand } = await findOcrTooltip(
                page,
                searchArea,
                expectedRubberbandHoverText,
                ocrToolTip
            );

            // Hover and double-click to apply OCR value
            const hoverPositionRubberband = {
                x: rubberBandCoords.x - boundingBox.x,
                y: rubberBandCoords.y - boundingBox.y,
            };
            await canvas.hover({ position: hoverPositionRubberband });
            await canvas.dblclick({ position: hoverPositionRubberband });

            // Verify field value
            await expect(organizationField).toBeFocused();
            await expect(organizationField).toHaveValue(ocrValueRubberBand.trim());
        });
    });

    test.describe('[XAT-17992] Double clicking an OCR value to apply it to the first field (Invoice)', () => {
        // This includes two tests to verify both states of the IdpFormAsMetadataPanel feature flag
        test(`XAT-17992 - OLD (Metadata Panel): Double clicking an OCR value to apply it to the first field (Invoice)`, async ({
            fieldVerificationPage,
            taskDetailsPage,
            runtimeBundleServiceHrUser: runtimeBundleService,
            page,
            skipOrExecuteTestBasedOnFlagStatus,
        }) => {
            // Test runs only when IdpFormAsMetadataPanel feature flag is OFF
            await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.IdpFormAsMetadataPanel, 'old-functionality');

            await test.step('Start and navigate to the user task', async () => {
                processInstance = await initializeTestAndNavigateToTask(batchRunnerInvoice, runtimeBundleService, taskDetailsPage, page);
            });

            // Variables
            const { canvas, boundingBox } = await validateCanvasAndGetBoundingBox(fieldVerificationPage);
            const ocrToolTip = fieldVerificationPage.fieldVerificationViewerTextLayer.ocrToolTip;
            const companyName = page.locator('[data-automation-id^="idp-field-Company"]');

            // Wait for the image to fully load
            await waitForImageToLoad(page, fieldVerificationPage);

            // Value for expected text from OCR tooltip and search area (adjust as needed)
            const expectedText = 'ERICSSON';
            const searchArea = {
                x: boundingBox.x + 75,
                y: boundingBox.y + 75,
                width: boundingBox.width / 4,
                height: boundingBox.height / 10,
            };

            // Find and set the coordinates of the tooltip with the expected text
            const matchedCoordinates = await findTooltipCoordinates(page, searchArea, expectedText);
            if (!matchedCoordinates) {
                throw new Error(`Tooltip with text "${expectedText}" not found in the specified area.`);
            }

            // Store the value of the tooltip text
            const ocrValue = await ocrToolTip.textContent();
            if (!ocrValue) {
                throw new Error('Failed to retrieve OCR value from tooltip.');
            }

            // Set the coordinates for the hover and double-click actions
            const hoverPosition = {
                x: matchedCoordinates.x - boundingBox.x,
                y: matchedCoordinates.y - boundingBox.y,
            };

            // Perform hover and double-click actions to apply the OCR value
            await canvas.hover({ position: hoverPosition });
            await canvas.dblclick({ position: hoverPosition });

            // Verify that the company name field is focused and has the expected value
            await expect(companyName).toBeFocused();
            await expect(companyName).toHaveValue(ocrValue.trim());
        });

        test(`XAT-17992 - NEW (Form): Double clicking an OCR value to apply it to the first field (Invoice)`, async ({
            fieldVerificationPage,
            taskDetailsPage,
            runtimeBundleServiceHrUser: runtimeBundleService,
            page,
            skipOrExecuteTestBasedOnFlagStatus,
        }) => {
            // Test runs only when IdpFormAsMetadataPanel feature flag is ON
            await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.IdpFormAsMetadataPanel, 'new-functionality');

            await test.step('Start and navigate to the user task', async () => {
                processInstance = await initializeTestAndNavigateToTask(batchRunnerInvoice, runtimeBundleService, taskDetailsPage, page);
            });

            // Variables
            const { canvas, boundingBox } = await validateCanvasAndGetBoundingBox(fieldVerificationPage);
            const ocrToolTip = fieldVerificationPage.fieldVerificationViewerTextLayer.ocrToolTip;
            const companyName = page.locator('input[id^="idp_Company"]');

            // Wait for the image to fully load
            await waitForImageToLoad(page, fieldVerificationPage);

            // Value for expected text from OCR tooltip and search area (adjust as needed)
            const expectedText = 'ERICSSON';
            const searchArea = {
                x: boundingBox.x + 75,
                y: boundingBox.y + 75,
                width: boundingBox.width / 4,
                height: boundingBox.height / 10,
            };

            // Find and set the coordinates of the tooltip with the expected text
            const matchedCoordinates = await findTooltipCoordinates(page, searchArea, expectedText);
            if (!matchedCoordinates) {
                throw new Error(`Tooltip with text "${expectedText}" not found in the specified area.`);
            }

            // Store the value of the tooltip text
            const ocrValue = await ocrToolTip.textContent();
            if (!ocrValue) {
                throw new Error('Failed to retrieve OCR value from tooltip.');
            }

            // Set the coordinates for the hover and double-click actions
            const hoverPosition = {
                x: matchedCoordinates.x - boundingBox.x,
                y: matchedCoordinates.y - boundingBox.y,
            };

            // Perform hover and double-click actions to apply the OCR value
            await canvas.hover({ position: hoverPosition });
            await canvas.dblclick({ position: hoverPosition });

            // Verify that the company name field is focused and has the expected value
            await expect(companyName).toBeFocused();
            await expect(companyName).toHaveValue(ocrValue.trim());
        });
    });

    test.describe('Double clicking on OCR values (Tables)', () => {
        test(`[XAT-17993] Double clicking a value to apply it to the first field`, async ({
            fieldVerificationPage,
            taskDetailsPage,
            runtimeBundleServiceHrUser: runtimeBundleService,
            page,
            skipOrExecuteTestBasedOnFlagStatus,
        }) => {
            // Any table related test will be skipped if the IdpFormAsMetadataPanel feature flag is ON
            // as the table functionality is not available in runtime forms replacing the metadata panel yet
            // Once the feature flag is removed these tests will run as normal
            await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.IdpFormAsMetadataPanel, 'old-functionality');

            // Initialize test and navigate to user task
            await test.step('Start and navigate to the user task', async () => {
                processInstance = await initializeTestAndNavigateToTask(batchRunnerSmallTables, runtimeBundleService, taskDetailsPage, page);
            });

            const { canvas, boundingBox } = await validateCanvasAndGetBoundingBox(fieldVerificationPage);
            const ocrToolTip = fieldVerificationPage.fieldVerificationViewerTextLayer.ocrToolTip;
            const organization = page.locator('[data-automation-id^="idp-field-Organization"]');

            // Wait for the image to fully load
            await waitForImageToLoad(page, fieldVerificationPage);

            // Value for expected text from OCR tooltip and search area (adjust as needed)
            const expectedText = 'Basketball';
            const searchArea = {
                x: boundingBox.x + 75,
                y: boundingBox.y + 150,
                width: boundingBox.width / 4,
                height: boundingBox.height / 3,
            };

            // Find and set the coordinates of the tooltip with the expected text
            const matchedCoordinates = await findTooltipCoordinates(page, searchArea, expectedText);
            if (!matchedCoordinates) {
                throw new Error(`Tooltip with text "${expectedText}" not found in the specified area.`);
            }

            // Store the value of the tooltip text
            const ocrValue = await ocrToolTip.textContent();
            if (!ocrValue) {
                throw new Error('Failed to retrieve OCR value from tooltip.');
            }

            // Set the coordinates for the hover and double-click actions
            const hoverPosition = {
                x: matchedCoordinates.x - boundingBox.x,
                y: matchedCoordinates.y - boundingBox.y,
            };

            // Perform hover and double-click actions to apply the OCR value
            await canvas.hover({ position: hoverPosition });
            await canvas.dblclick({ position: hoverPosition });

            // Verify that the company name field is focused and has the expected value
            await expect(organization).toBeFocused();
            await expect(organization).toHaveValue(ocrValue.trim());

            // Verify a table field is focused and has the expected value
            const metadataPanel = fieldVerificationPage.metadataPanel;
            // eslint-disable-next-line @cspell/spellchecker
            const minutesPlayedTableId = 'MinutesPlayed0ikpdt';

            await metadataPanel.openTableForField(minutesPlayedTableId);

            // Perform hover and double-click actions to apply the OCR value to the table field
            await canvas.hover({ position: hoverPosition });
            await canvas.dblclick({ position: hoverPosition });

            // Wait until the table cell input value updates to the expected value
            const tableCellInput = page.locator('.idp-cell-edit-input').first();
            await expect(tableCellInput).toBeVisible();
            await expect(tableCellInput).toHaveValue('Basketball'); // Adjust based on the actual expected value
        });
    });
});
