/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { FeaturesServiceToken } from '@alfresco/adf-core/feature-flags';
import { ADF_HX_CONTENT_SERVICES_INTERNAL } from '@alfresco/adf-hx-content-services/features';
import { HxpPropertiesSidebarLegacyComponent } from '../properties-sidebar-legacy/hxp-properties-sidebar-legacy.component';
import { HxpMetadataSidebarComponent } from '../metadata-sidebar/hxp-metadata-sidebar.component';
import { toSignal } from '@angular/core/rxjs-interop';

/**
 * Sidebar component to display and edit a Document properties.
 *
 * To use the `HxpPropertiesSidebarComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpPropertiesSidebarComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         HxpPropertiesSidebarComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 *
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-properties-sidebar [editable]="false" [document]="document" (closePropertySidebar)="onClose()">
 */
@Component({
    selector: 'hxp-properties-sidebar',
    templateUrl: './hxp-properties-sidebar.component.html',
    standalone: true,
    imports: [MatButtonModule, MatIconModule, MatProgressSpinnerModule, HxpPropertiesSidebarLegacyComponent, HxpMetadataSidebarComponent],
})
export class HxpPropertiesSidebarComponent {
    /**
     * The document to display the properties for
     * @type {Document}
     */
    @Input() document?: Document;

    /**
     * Input property to enable or disable edit mode availability
     * @type {boolean}
     * @default true
     */
    @Input() editable = true;

    /**
     * Emits an event when the sidebar is closed
     */
    @Output() closePropertySidebar = new EventEmitter<void>();

    protected readonly featuresService = inject(FeaturesServiceToken);
    protected readonly isMetadataPanelFeatureFlagOn = toSignal(
        this.featuresService.isOn$(ADF_HX_CONTENT_SERVICES_INTERNAL.CIC_WORKSPACE_NEW_METADATA_PANEL)
    );

    /**
     * Handles the close event from child components and re-emits it
     */
    protected onClosePropertySidebar(): void {
        this.closePropertySidebar.emit();
    }
}
