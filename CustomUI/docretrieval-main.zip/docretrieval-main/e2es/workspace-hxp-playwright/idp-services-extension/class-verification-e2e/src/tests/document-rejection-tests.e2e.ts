/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { ProcessInstanceData, RequestResponse, getUserState } from '@alfresco-dbp/playwright/shared';
import { test, expect, idpHelperMethods, IdpBatchStateSnapshotRunner } from '@hxp/playwright/workspace-hxp';
import { BATCH_STATE_SNAPSHOTS } from '../resources';
const { refreshUserState, waitForUserTask } = idpHelperMethods;

test.use({ storageState: getUserState('hruser') });

test.describe('Workspace IDP Tests - Start IDP process', () => {
    let processInstance: ProcessInstanceData | RequestResponse | undefined;
    let batchRunner: IdpBatchStateSnapshotRunner;

    test.beforeAll(async ({ idpBatchStateSnapshotInitializer }) => {
        batchRunner = await idpBatchStateSnapshotInitializer.upload(BATCH_STATE_SNAPSHOTS.twoInvoices);
    });

    test.beforeEach(async ({ tasksPage }, workerInfo) => {
        await refreshUserState(tasksPage, workerInfo);
    });

    test.afterEach(async ({ runtimeBundleServiceHrUser: runtimeBundleService }) => {
        await runtimeBundleService.processInstance.deleteProcessesIfExist(processInstance?.entry?.id);
        processInstance = undefined;
    });

    test(`[XAT-17694] Reject Document Testing`, async ({
        taskDetailsPage,
        runtimeBundleServiceHrUser: runtimeBundleService,
        idpClassificationPage,
    }) => {
        await test.step('Start the process', async () => {
            processInstance = await batchRunner.startProcess(runtimeBundleService);
        });

        const userTasks = await waitForUserTask(runtimeBundleService, processInstance);
        await taskDetailsPage.navigate({ query: `/${userTasks[0].entry.id}`, waitUntil: 'load' });
        await idpClassificationPage.documentBrowser.sortByOption.click();
        await idpClassificationPage.overlayContainer.sortOption1.click();

        // Reject button is enabled when one or more non rejected documents are selected
        await expect(idpClassificationPage.floaterToolbar.rejectButton).toBeEnabled();
        await idpClassificationPage.documentBrowser
            .getClass(2)
            .getDocument(1)
            .getRootLocator.click({ modifiers: ['Shift'] });
        await expect(idpClassificationPage.floaterToolbar.rejectButton).toBeEnabled();

        // Dialog can be launched using keyboard shortcut
        await idpClassificationPage.page.keyboard.press('Shift+R');

        // Reject button should be enabled once a reason is selected
        await idpClassificationPage.rejectClassDialog.fadedRejectReason.click();
        await expect(idpClassificationPage.rejectClassDialog.submitChangeButton).toBeEnabled();

        // Documents should not be rejected when dialog is canceled
        await idpClassificationPage.rejectClassDialog.cancelButton.click();

        // Dialog can be launched using reject button
        await idpClassificationPage.documentBrowser.getClass(2).getDocument(0).getRootLocator.click();
        await idpClassificationPage.floaterToolbar.rejectButton.click();

        // Test Reject a document
        await idpClassificationPage.rejectClassDialog.fadedRejectReason.click();
        await idpClassificationPage.rejectClassDialog.rejectNoteInputField.fill('Reject Note');
        await idpClassificationPage.rejectClassDialog.submitChangeButton.click();

        // Reject button should be enabled when one rejected document is selected
        await expect(idpClassificationPage.documentBrowser.getClass(0).getRootLocator).toBeEnabled();
        await idpClassificationPage.documentBrowser.getClass(0).getRootLocator.click();
        await expect(idpClassificationPage.floaterToolbar.rejectButton).toHaveCount(1);

        // Reject Flag keeps previous note and can also be removed completely
        await idpClassificationPage.floaterToolbar.rejectButton.click();
        await expect(idpClassificationPage.rejectClassDialog.rejectNoteInputField).toHaveValue('Reject Note');
        await idpClassificationPage.rejectClassDialog.removeRejectFlagButton.click();
        await expect(idpClassificationPage.documentBrowser.getClass(2).getRootLocator).toHaveCount(1);
    });
});
