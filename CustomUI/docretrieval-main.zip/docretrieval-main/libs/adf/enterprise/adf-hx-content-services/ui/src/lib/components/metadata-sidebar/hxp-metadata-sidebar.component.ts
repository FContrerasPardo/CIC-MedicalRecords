/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { CardViewItem, CardViewUpdateService, InfoDrawerContentDirective, InfoDrawerLayoutComponent, UpdateNotification } from '@alfresco/adf-core';
import { Component, DestroyRef, EventEmitter, HostListener, inject, Inject, Input, OnChanges, Output, ViewEncapsulation } from '@angular/core';
import {
    DOCUMENT_PROPERTIES_SERVICE,
    DocumentService,
    isVersion,
    HxpNotificationService,
    SharedDocumentPropertiesService,
} from '@alfresco/adf-hx-content-services/services';
import { Observable } from 'rxjs';
import { take, finalize, filter, map } from 'rxjs/operators';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { AsyncPipe } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { TranslatePipe } from '@ngx-translate/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { editPropertiesNotificationMessages } from './configs/edit-properties-notification-messages.config';
import { editPropertiesSnackBarTypes } from './configs/edit-properties-snack-bar-types.model';
import { EditPropertiesStatus } from './configs/edit-properties-status.enum';
import { MetadataSidebarContentComponent } from '../metadata-sidebar-content/metadata-sidebar-content.component';
import { MatTabsModule } from '@angular/material/tabs';
import { MetadataSidebarService } from './hxp-metadata-sidebar.service';
import { FieldType } from '@alfresco/adf-hx-content-services/api';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { HxpCancelMetadataSidebarEditDialogComponent } from '../metadata-sidebar-cancel-edit-dialog/hxp-cancel-metadata-sidebar-edit-dialog.component';
import { DialogConfig } from '../../util/dialog/config';
import { HxpMetadataSidebarAdditionalInfoComponent } from '../metadata-sidebar-additional-info/hxp-metadata-sidebar-additional-info.component';

/**
 * Sidebar component to display and edit a Document properties.
 *
 * To use the `HxpMetadataSidebarComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpMetadataSidebarComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         HxpMetadataSidebarComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 *
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-metadata-sidebar [editable]="false" [document]="document" (closePropertySidebar)="onClose()">
 */
@Component({
    selector: 'hxp-metadata-sidebar',
    templateUrl: './hxp-metadata-sidebar.component.html',
    styleUrls: ['./hxp-metadata-sidebar.component.scss'],
    encapsulation: ViewEncapsulation.None,
    standalone: true,
    imports: [
        InfoDrawerLayoutComponent,
        InfoDrawerContentDirective,
        MatButtonModule,
        MatIconModule,
        MatTabsModule,
        MatProgressSpinnerModule,
        MatTooltipModule,
        MetadataSidebarContentComponent,
        AsyncPipe,
        TranslatePipe,
        HxpMetadataSidebarAdditionalInfoComponent,
    ],
})
export class HxpMetadataSidebarComponent implements OnChanges {
    private readonly destroyRef = inject(DestroyRef);
    private readonly metadataSidebarService = inject(MetadataSidebarService);

    /**
     * The document to display the properties for
     * @type {Document}
     */
    @Input() document?: Document;

    /**
     * Input property to enable or disable edit mode availability
     * @type {boolean}
     * @default true
     */
    @Input() editable = true;

    /**
     * Emits an event when the sidebar is closed
     */
    @Output() closePropertySidebar = new EventEmitter<void>();

    protected propertyLoading = false;
    protected selectedDocument!: Document;
    protected editableSystemProperties$!: Observable<CardViewItem[]>;
    protected nonEditableSystemProperties$!: Observable<CardViewItem[]>;
    protected customProperties$!: Observable<CardViewItem[]>;
    protected workingCopy = true;
    protected isEditableRecord = false;
    protected editMode = false;
    protected hasPendingChanges = false;
    protected isUpdateInProgress = false;

    private cardValueValidationMap: Record<string, boolean> = {};
    private documentPropertiesToUpdate: Partial<Document> = {};
    private requiredProperties: string[];
    private dialogRef: MatDialogRef<HxpCancelMetadataSidebarEditDialogComponent> | null = null;

    constructor(
        private readonly documentService: DocumentService,
        private readonly hxpNotificationService: HxpNotificationService,
        private readonly cardViewUpdateService: CardViewUpdateService,
        private readonly dialog: MatDialog,
        @Inject(DOCUMENT_PROPERTIES_SERVICE) private readonly documentPropertiesService: SharedDocumentPropertiesService
    ) {
        this.subscribeToDocumentUpdates();
        this.requiredProperties = this.documentPropertiesService.getRequiredProperties();
        this.cardViewUpdateService.itemUpdated$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(this.respondToCardUpdate.bind(this));
    }

    ngOnChanges() {
        this.loadDocumentProperties(this.document?.sys_id ?? '');
        if (this.document) {
            this.workingCopy = !isVersion(this.document);
        }
    }

    @HostListener('keydown', ['$event'])
    onSidebarKeyDown(event: KeyboardEvent) {
        if (event.key === 'Escape') {
            if (this.hasPendingChanges) {
                event.stopPropagation();
                event.preventDefault();
                if (!this.dialogRef) {
                    this.openCancelDialog();
                }
            } else {
                return this.closeSidebar();
            }
        }
    }

    protected onCancel() {
        if (!this.hasPendingChanges) {
            return this.closeSidebar();
        }
        this.openCancelDialog();
    }

    protected handlePropertyUpdate(propertyUpdated: boolean): void {
        if (propertyUpdated) {
            this.fetchEditableProperties();
            this.fetchCustomProperties();
        }
    }

    protected onClose(): void {
        if (!this.hasPendingChanges) {
            this.closePropertySidebar.emit();
            return this.closeSidebar();
        }
        this.openCancelDialog();
    }

    private openCancelDialog() {
        this.dialogRef = this.dialog.open(HxpCancelMetadataSidebarEditDialogComponent, { width: DialogConfig.small.width });
        this.dialogRef.componentInstance.discardChanges.subscribe(() => {
            this.closeSidebar();
        });

        this.dialogRef.componentInstance.saveChanges.subscribe(() => {
            this.onSaveProperties();
        });

        this.dialogRef.afterClosed().subscribe(() => {
            this.dialogRef = null;
        });
    }

    private closeSidebar(): void {
        this.documentPropertiesToUpdate = {};
        this.cardValueValidationMap = {};
        this.fetchEditableProperties();
        this.fetchNonEditableProperties();
        this.fetchCustomProperties();
        this.editMode = false;
        this.hasPendingChanges = false;
    }

    private subscribeToDocumentUpdates(): void {
        this.documentService.documentUpdated$
            .pipe(
                filter(({ document }) => !!document && document.sys_id === this.document?.sys_id),
                takeUntilDestroyed(this.destroyRef)
            )
            .subscribe({
                next: ({ document }) => {
                    if (document) {
                        this.selectedDocument = document;
                        this.fetchDocumentProperties();
                    }
                },
                error: (error) => console.error(error),
            });
    }

    private loadDocumentProperties(documentId: string): void {
        if (!documentId) {
            return;
        }

        this.propertyLoading = true;
        this.documentService
            .getDocumentById(documentId)
            .pipe(
                take(1),
                finalize(() => (this.propertyLoading = false))
            )
            .subscribe({
                next: (doc) => {
                    this.selectedDocument = doc;
                    this.fetchDocumentProperties();
                },
                error: ({ error }) => {
                    console.error(error);
                },
            });
    }

    private fetchDocumentProperties(): void {
        if (!this.selectedDocument) {
            return;
        }

        this.documentPropertiesService
            .extractCustomSchemaFields(this.selectedDocument.sys_primaryType)
            .pipe(take(1))
            .subscribe({
                next: (schemaFields: Record<string, any>) => {
                    this.initializeDocumentWithSchema(schemaFields);
                },
                error: (error) => console.error(error),
            });

        this.fetchEditableProperties();
        this.fetchNonEditableProperties();
        this.fetchCustomProperties();
    }

    private initializeDocumentWithSchema(schemaFields: Record<string, any>, currentDoc: Record<string, any> = this.selectedDocument): void {
        for (const fieldName of Object.keys(schemaFields)) {
            if (!currentDoc[fieldName]) {
                currentDoc[fieldName] = typeof schemaFields[fieldName] === 'object' ? {} : '';
            }
            if (typeof schemaFields[fieldName] === 'object') {
                this.initializeDocumentWithSchema(schemaFields[fieldName], currentDoc[fieldName]);
            }
        }
    }

    private fetchEditableProperties(): void {
        this.editableSystemProperties$ = this.metadataSidebarService.getEditableSystemPropertiesFromDocument(this.selectedDocument);
    }

    private fetchNonEditableProperties(): void {
        this.nonEditableSystemProperties$ = this.metadataSidebarService.getNonEditableSystemPropertiesFromDocument(this.selectedDocument).pipe(
            map((properties) => {
                // To ensure sys_path is always the last property displayed
                const pathProperties = properties.filter((p) => p.label?.toLowerCase() === 'path');
                const otherProperties = properties.filter((p) => p.label?.toLowerCase() !== 'path');
                return [...otherProperties, ...pathProperties];
            })
        );
    }

    private fetchCustomProperties(): void {
        this.customProperties$ = this.metadataSidebarService.getCustomProperties(this.selectedDocument);
    }

    private respondToCardUpdate(updateNotification: UpdateNotification): void {
        const changedKey = Object.keys(updateNotification.changed)[0];
        const changedValue = updateNotification.changed[changedKey];

        const fieldType: FieldType | undefined = this.documentPropertiesService.propertyType(changedKey);

        this.cardValueValidationMap[changedKey] = this.validateCardValue(changedKey, changedValue, fieldType);

        if (!this.cardValueValidationMap[changedKey]) {
            return;
        }

        this.hasPendingChanges = true;

        const updatedValue = this.isComplexProperty(changedValue, fieldType)
            ? this.getUpdatedComplexProperty(changedKey, changedValue)
            : updateNotification.changed;

        this.documentPropertiesToUpdate = {
            ...this.documentPropertiesToUpdate,
            ...updatedValue,
        };
    }

    private validateCardValue(changedKey: string, changedValue: any, fieldType?: FieldType) {
        let invalidCardValue = false;
        if (fieldType === FieldType.Blob || fieldType === FieldType.Complex) {
            const nestedPropertyName: string = Object.keys(changedValue)[0];
            if (this.isEmptyProperty(changedValue[`${nestedPropertyName}`])) {
                invalidCardValue = this.handleEmptyProperty(`${changedKey}.${nestedPropertyName || ''}`);
            }
        } else if (this.isEmptyProperty(changedValue)) {
            invalidCardValue = this.handleEmptyProperty(changedKey);
        }

        return !invalidCardValue;
    }

    private isComplexProperty(changedValue: any, fieldType: FieldType | undefined) {
        return fieldType === FieldType.Complex || (fieldType !== FieldType.Date && typeof changedValue === 'object' && !Array.isArray(changedValue));
    }

    private isEmptyProperty(changedValue: any): boolean {
        return !changedValue;
    }

    private handleEmptyProperty(propertyName: string): boolean {
        if (this.requiredProperties.includes(propertyName)) {
            this.hxpNotificationService.openSnackBar(
                editPropertiesNotificationMessages[EditPropertiesStatus.INFO],
                editPropertiesSnackBarTypes[EditPropertiesStatus.INFO]
            );
            return true;
        }
        return false;
    }

    private getUpdatedComplexProperty(changedKey: string, changedValue: any): Partial<Document> {
        const existingDataInDocument = this.document?.[changedKey] || {};
        const existingUpdateData = this.documentPropertiesToUpdate[changedKey] || {};

        return {
            [changedKey]: {
                ...existingDataInDocument,
                ...existingUpdateData,
                ...changedValue,
            },
        };
    }

    protected enableEditMode() {
        this.editMode = true;
        this.isUpdateInProgress = false;
        this.documentPropertiesToUpdate = {};
    }

    protected hasBeenModified(): boolean {
        return Object.keys(this.documentPropertiesToUpdate).length > 0;
    }

    protected allCardValuesAreValid(): boolean {
        return Object.keys(this.documentPropertiesToUpdate).every((changedKey) => this.cardValueValidationMap[changedKey]);
    }

    protected onSaveProperties() {
        if (!this.document?.sys_id) {
            return;
        }
        this.isUpdateInProgress = true;
        this.documentService
            .updateDocument(this.document.sys_id, this.documentPropertiesToUpdate)
            .pipe(
                take(1),
                finalize(() => {
                    this.isUpdateInProgress = false;
                })
            )
            .subscribe({
                next: (document) => {
                    this.document = document;
                    this.documentPropertiesToUpdate = {};
                    this.hasPendingChanges = false;
                    this.editMode = false;
                    this.hxpNotificationService.openSnackBar(
                        editPropertiesNotificationMessages[EditPropertiesStatus.SUCCESS],
                        editPropertiesSnackBarTypes[EditPropertiesStatus.SUCCESS]
                    );
                },
                error: () => {
                    this.hxpNotificationService.openSnackBar(
                        editPropertiesNotificationMessages[EditPropertiesStatus.ERROR],
                        editPropertiesSnackBarTypes[EditPropertiesStatus.ERROR]
                    );
                },
            });
    }
}
