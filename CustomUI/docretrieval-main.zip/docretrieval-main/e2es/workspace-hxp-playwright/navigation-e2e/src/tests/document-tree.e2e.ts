/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { getUserState } from '@alfresco-dbp/playwright/shared';
import { ContentBrowserLabels, expect, test } from '@hxp/playwright/workspace-hxp';
import { Document } from '@hylandsoftware/hxcs-js-client';

test.describe('Content Tree Navigation As HR User', async () => {
    const expectedActions: string[] = ['Share', 'Copy'];
    let parentFolder: Document;
    let childFolder: Document;
    let file: Document;

    test.use({ storageState: getUserState('hruser') });

    test.beforeEach(async ({ contentBrowserPage, hxprApi }, workerInfo) => {
        await contentBrowserPage.refreshUserState('hruser', workerInfo.project.use);

        parentFolder = await hxprApi.documentServiceApi.createFolderWithPermissions('Navigation', 'document-tree:hruser', 'hr');
        childFolder = await hxprApi.documentServiceApi.createFolder('Child Folder', 'Child Folder description', parentFolder.sys_id);
        file = await hxprApi.documentServiceApi.createFile('EmptyFile', 'File description', childFolder.sys_id);

        await contentBrowserPage.navigateToRoot();
    });

    test.afterEach(async ({ hxprApi }) => hxprApi.documentServiceApi.teardown());

    test(`[C694999] User should be able to navigate to parent folder`, async ({ contentBrowserPage }) => {
        await contentBrowserPage.contentSideNavbar.navigateTo(ContentBrowserLabels.HomeLabel);
        await expect(contentBrowserPage.contentSideNavbar.getContentMenuItemByName('Home')).toBeVisible();

        await contentBrowserPage.contentSideNavbar.contentBrowserNavigateTo(parentFolder.sys_title);
        await expect(contentBrowserPage.contentSideNavbar.getContentMenuItemByName(parentFolder.sys_title)).toBeVisible();
        await expect(contentBrowserPage.contentSideNavbar.getContentMenuItemByName(childFolder.sys_title)).toBeVisible();

        await expect(contentBrowserPage.mainContentContainer.getDocByTestId(childFolder.sys_title)).toBeVisible();
    });

    test(`[C695000] User should be able to navigate to the child folder`, async ({ contentBrowserPage }) => {
        await contentBrowserPage.contentSideNavbar.navigateTo(ContentBrowserLabels.HomeLabel);
        await expect(contentBrowserPage.contentSideNavbar.getContentMenuItemByName('Home')).toBeVisible();

        await contentBrowserPage.contentSideNavbar.contentBrowserNavigateTo(parentFolder.sys_title);

        await contentBrowserPage.contentSideNavbar.contentBrowserNavigateTo(childFolder.sys_title);

        await expect(contentBrowserPage.contentSideNavbar.getContentMenuItemByName(parentFolder.sys_title)).toBeVisible();
        await expect(contentBrowserPage.contentSideNavbar.getContentMenuItemByName(childFolder.sys_title)).toBeVisible();

        await expect(contentBrowserPage.mainContentContainer.getDocByTestId(file.sys_title)).toBeVisible();
    });

    test(`[XAT-373] User should see correct action names in contextual menu`, async ({ contentBrowserPage }) => {
        await test.step('Validate the contextual menu action names through right click on folder', async () => {
            await contentBrowserPage.mainContentContainer.waitForRootElement();
            await contentBrowserPage.contentSideNavbar.getRowByName(parentFolder.sys_title).click({ button: 'right' });

            expect.soft(await contentBrowserPage.hxpContextMenuComponent.getAllActionNames()).toEqual(expectedActions);
        });

        await test.step('Validate the contextual menu action names through clicking on ellipsis button for a folder', async () => {
            await contentBrowserPage.reload();
            await contentBrowserPage.mainContentContainer.waitForRootElement();
            await contentBrowserPage.contentSideNavbar.getEllipsisByTitle(parentFolder.sys_title).click();

            expect(await contentBrowserPage.hxpContextMenuComponent.getAllActionNames()).toEqual(expectedActions);
        });
    });
});

test.describe('Content Tree Navigation as Repo Admin', async () => {
    const expectedActions: string[] = ['Share', 'Delete', 'Copy', 'Move', 'Permissions'];

    test.use({ storageState: getUserState('repoadmin') });

    test(`[XAT-18483] User should see correct action names in contextual menu`, async ({ contentBrowserPage, hxprApi }) => {
        const parentFolder = await hxprApi.documentServiceApi.createFolderWithPermissions('Navigation', 'document-tree:repoadmin', 'repoadmin');

        await contentBrowserPage.navigateToRoot();

        await test.step('Validate the contextual menu action names through right click on folder', async () => {
            await contentBrowserPage.mainContentContainer.waitForRootElement();
            await contentBrowserPage.contentSideNavbar.getRowByName(parentFolder.sys_title).click({ button: 'right' });

            expect.soft(await contentBrowserPage.hxpContextMenuComponent.getAllActionNames()).toEqual(expectedActions);
        });

        await test.step('Validate the contextual menu action names through clicking on ellipsis button for a folder', async () => {
            await contentBrowserPage.reload();
            await contentBrowserPage.mainContentContainer.waitForRootElement();
            await contentBrowserPage.contentSideNavbar.getEllipsisByTitle(parentFolder.sys_title).click();

            expect(await contentBrowserPage.hxpContextMenuComponent.getAllActionNames()).toEqual(expectedActions);
        });
    });
});
