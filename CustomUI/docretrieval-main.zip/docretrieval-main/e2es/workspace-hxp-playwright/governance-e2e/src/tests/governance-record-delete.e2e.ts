/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { getUserState, files } from '@alfresco-dbp/playwright/shared';
import { expect, test } from '@hxp/playwright/workspace-hxp';
import { Document } from '@hylandsoftware/hxcs-js-client';

const baseDate = new Date();
let parentFolder: Document;
let uploadedFile: Document;
let uploadedFileTitle: string;

test.use({ storageState: getUserState('repoadmin') });

test.describe('Governance Search', async () => {
    test.beforeEach(async ({ governancePage, hxprApi }) => {
        const tomorrowDate = new Date(Date.UTC(baseDate.getFullYear(), baseDate.getMonth(), baseDate.getDate() + 1, 0, 0, 0, 0));
        const tomorrowDateISO = tomorrowDate.toISOString();

        parentFolder = await hxprApi.documentServiceApi.createFolder('Parent Folder', 'Folder description');
        uploadedFile = await hxprApi.uploadServiceApi.uploadFile(files.pdfFile, parentFolder.sys_id, {
            sys_primaryType: 'e2e-cutoff-date',
            co_e2e_cutoff_date: tomorrowDateISO,
        });
        uploadedFileTitle = uploadedFile.sys_title;
        await governancePage.navigate();
        await governancePage.governanceManagementTabs.recordsManagementTab.click();
        await governancePage.searchResults.searchInitialLabel.waitFor();

        const isRecordAvailable = await governancePage.checkForRecord(uploadedFileTitle);

        if (!isRecordAvailable) {
            throw new Error(`Setup failed: Record "${uploadedFileTitle}" not available`);
        }
        await governancePage.searchResults.resetButtonLocator.click();
    });

    test.afterEach(async ({ hxprApi }) => hxprApi.documentServiceApi.teardown());

    test(`[XAT-18279] User should be able to delete record`, async ({ governancePage }) => {
        await governancePage.recordNameFilter.recordNameFilterLocator.click();
        await governancePage.overlayActions.recordNameInputLocator.fill(uploadedFileTitle);
        await governancePage.overlayActions.applyButton.click();
        await governancePage.searchResults.changePageSize('100');
        await governancePage.recordList.getCheckboxByRow(uploadedFileTitle).click();
        await governancePage.searchResultsActions.recordDeleteButton.click();
        await governancePage.searchResultsActions.deleteConfirmationButton.click();

        await expect.soft(governancePage.snackBar.message).toContainText('Record(s) deleted successfully!');
        await expect(governancePage.recordList.getRowByName(uploadedFileTitle)).not.toBeVisible();
    });
});
