/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { AppNames, CustomConfig, getExcludedTestsRegExpArray, getGlobalConfig, HXP_APPS } from '@alfresco-dbp/playwright/shared';
import { Project, defineConfig } from '@playwright/test';
import EXCLUDED_JSON from './exclude.tests.json';

const projectConfiguration: Project<CustomConfig>[] = [
    {
        name: 'Governance - Workspace HxP Tests',
        use: {
            loginPage: 'HxpLoginPage',
            users: ['repoadmin'],
            testIdAttribute: 'data-automation-id',
            environmentCheck: {
                apps: false,
                envUp: false,
            },
            // eslint-disable-next-line @cspell/spellchecker
            remoteRoutePath: 'ui/workspace-1akyy/',
            hxpModelingProjectName: HXP_APPS.SYS_GOVERNANCE.appName,
            permissions: ['clipboard-read'],
        },
    },
];

export default defineConfig<CustomConfig>({
    ...getGlobalConfig(AppNames.WorkspaceHxPGovernance, projectConfiguration),
    grepInvert: getExcludedTestsRegExpArray(EXCLUDED_JSON, AppNames.WorkspaceHxPGovernance),
    maxFailures: 5,
});
