/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/**
 * @internal
 */
export const ADF_HX_CONTENT_SERVICES_INTERNAL = {
    CIC_WORKSPACE_SATORI_APPLICATION_CHROME: 'cic-workspace-satori-application-chrome',
    CIC_WORKSPACE_NEW_METADATA_PANEL: 'cic-workspace-new-metadata-panel',
    CIC_GOVERNANCE_DASHBOARD_FEATURE: 'cic-governance-dashboard-feature',
} as const;

export type ADF_HX_CONTENT_SERVICES_INTERNAL = typeof ADF_HX_CONTENT_SERVICES_INTERNAL[keyof typeof ADF_HX_CONTENT_SERVICES_INTERNAL];
