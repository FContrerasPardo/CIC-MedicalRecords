/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { getUserState, files } from '@alfresco-dbp/playwright/shared';
import { expect, test } from '@hxp/playwright/workspace-hxp';
import { Document } from '@hylandsoftware/hxcs-js-client';

const dataSourceName = 'HXPR0000';
const categoryName = 'e2e-ci…/e2e-im…';
const status = 'Under Retention';
const dispositionDate = 'Tomorrow';
const initialLabelText = 'Search for records using advanced filtering';
const creatorAndModifierName = 'repoadmin repoadmin';
const statusReady = 'Ready';
const cutoffDateTomorrow = 'Tomorrow';
const baseDate = new Date();
let parentFolder: Document;
let uploadedFile: Document;
let uploadedFileTitle: string;

test.use({ storageState: getUserState('repoadmin') });

test.describe('Governance Search', async () => {
    test.beforeEach(async ({ governancePage, hxprApi }) => {
        parentFolder = await hxprApi.documentServiceApi.createFolder('Parent Folder', 'Folder description');
        uploadedFile = await hxprApi.uploadServiceApi.uploadFile(files.pdfFile, parentFolder.sys_id, {
            sys_primaryType: 'e2e-immediate',
        });
        uploadedFileTitle = uploadedFile.sys_title;
        await governancePage.navigate();
        await governancePage.governanceManagementTabs.recordsManagementTab.click();
        await governancePage.searchResults.searchInitialLabel.waitFor();

        const isRecordAvailable = await governancePage.checkForRecord(uploadedFileTitle);

        if (!isRecordAvailable) {
            throw new Error(`Setup failed: Record "${uploadedFileTitle}" not available`);
        }
        await governancePage.searchResults.resetButtonLocator.click();
    });

    test.afterEach(async ({ hxprApi }) => hxprApi.documentServiceApi.teardown());

    test(`[XAT-18234] User should be able to filter records by Data Source`, async ({ governancePage }) => {
        await governancePage.dataSourceSearchFilter.dataSourceFilterLocator.click();
        await governancePage.multiSelectionFilter.matSelectionList.getCheckboxByLabel(dataSourceName).click();
        await governancePage.overlayActions.applyButton.click();

        await expect(governancePage.recordList.getRootLocator).toBeVisible();
    });

    test(`[XAT-18235] User should be able to filter records by Category`, async ({ governancePage }) => {
        await governancePage.categoryFilter.categoryFilterLocator.click();
        await governancePage.multiSelectionFilter.matSelectionList.getCheckboxByLabel(categoryName).click();
        await governancePage.overlayActions.applyButton.click();
        await governancePage.searchResults.changePageSize('100');
        const recordExists = await governancePage.recordList.isRecordVisibleAcrossPages(uploadedFileTitle);

        expect.soft(recordExists).toBe(true);
        await expect(governancePage.recordList.getCategoryCellByRow(uploadedFileTitle)).toContainText(' e2e-immediate ');
    });

    test(`[XAT-18240] User should be able to filter records by Status`, async ({ governancePage }) => {
        await governancePage.statusFilter.statusFilterLocator.click();
        await governancePage.multiSelectionFilter.matSelectionList.getCheckboxByLabel(status).click();
        await governancePage.overlayActions.applyButton.click();
        await governancePage.searchResults.changePageSize('100');
        const recordExists = await governancePage.recordList.isRecordVisibleAcrossPages(uploadedFileTitle);

        expect.soft(recordExists).toBe(true);
        await expect(governancePage.recordList.getStatusCellByRow(uploadedFileTitle)).toContainText(status);
    });

    test(`[XAT-18245] User should be able to filter records by Record Name`, async ({ governancePage }) => {
        await governancePage.recordNameFilter.recordNameFilterLocator.click();
        await governancePage.overlayActions.recordNameInputLocator.fill(uploadedFileTitle);
        await governancePage.overlayActions.applyButton.click();
        await governancePage.searchResults.changePageSize('100');
        const recordExists = await governancePage.recordList.isRecordVisibleAcrossPages(uploadedFileTitle);

        expect(recordExists).toBe(true);
    });

    test(`[XAT-18265] User should be able to filter by Disposition Date`, async ({ governancePage }) => {
        await governancePage.dispositionDateFilter.dispositionDateFilterLocator.click();
        await governancePage.multiSelectionFilter.matSelectionList.getListItemByLabel(dispositionDate).click();
        await governancePage.overlayActions.applyButton.click();
        await governancePage.searchResults.changePageSize('100');
        const recordExists = await governancePage.recordList.isRecordVisibleAcrossPages(uploadedFileTitle);

        expect(recordExists).toBe(true);
    });

    test(`[XAT-18273] User should be able to reset search filters`, async ({ governancePage }) => {
        await governancePage.dataSourceSearchFilter.dataSourceFilterLocator.click();
        await governancePage.multiSelectionFilter.matSelectionList.getCheckboxByLabel(dataSourceName).click();
        await governancePage.overlayActions.applyButton.click();
        await governancePage.searchResults.resetButtonLocator.click();

        await expect(governancePage.searchResults.searchInitialLabel).toContainText(initialLabelText);
    });
});

test.describe('Governance Property-Based Search', async () => {
    test.beforeEach(async ({ governancePage, hxprApi }) => {
        const tomorrowDate = new Date(Date.UTC(baseDate.getFullYear(), baseDate.getMonth(), baseDate.getDate() + 1, 0, 0, 0));
        const tomorrowDateISO = tomorrowDate.toISOString();

        parentFolder = await hxprApi.documentServiceApi.createFolder('Parent Folder', 'Folder description');
        uploadedFile = await hxprApi.uploadServiceApi.uploadFile(files.pdfFile, parentFolder.sys_id, {
            sys_primaryType: 'e2e-cutoff-date',
            co_e2e_cutoff_date: tomorrowDateISO,
        });
        uploadedFileTitle = uploadedFile.sys_title;
        await governancePage.navigate();
        await governancePage.governanceManagementTabs.recordsManagementTab.click();
        await governancePage.searchResults.searchInitialLabel.waitFor();

        const isRecordAvailable = await governancePage.checkForRecord(uploadedFileTitle);

        if (!isRecordAvailable) {
            throw new Error(`Setup failed: Record "${uploadedFileTitle}" not available`);
        }
        await governancePage.searchResults.resetButtonLocator.click();
    });

    test.afterEach(async ({ hxprApi }) => hxprApi.documentServiceApi.teardown());

    test(`[XAT-18238] User should be able to filter by Cutoff Date`, async ({ governancePage }) => {
        await governancePage.cutoffDateFilter.cutoffDateFilterLocator.click();
        await governancePage.multiSelectionFilter.matSelectionList.getListItemByLabel(cutoffDateTomorrow).click();
        await governancePage.overlayActions.applyButton.click();
        await governancePage.searchResults.changePageSize('100');
        const recordExists = await governancePage.recordList.isRecordVisibleAcrossPages(uploadedFileTitle);

        expect.soft(recordExists).toBe(true);
        await expect(governancePage.recordList.getStatusCellByRow(uploadedFileTitle)).toContainText(statusReady);
    });

    test(`[XAT-18242] User should be able to filter by Modifier`, async ({ governancePage }) => {
        await governancePage.cutoffDateFilter.cutoffDateFilterLocator.click();
        await governancePage.multiSelectionFilter.matSelectionList.getListItemByLabel(cutoffDateTomorrow).click();
        await governancePage.overlayActions.applyButton.click();
        await governancePage.searchResults.changePageSize('100');
        const recordExistsBeforeModify = await governancePage.recordList.isRecordVisibleAcrossPages(uploadedFileTitle);

        expect.soft(recordExistsBeforeModify).toBe(true);

        await governancePage.recordList.getCheckboxByRow(uploadedFileTitle).click();
        await governancePage.searchResultsActions.recordPropertiesButton.click();
        await governancePage.recordPropertiesSidebar.editButton.click();
        await governancePage.recordPropertiesSidebar.calenderIcon.click();

        const futureDate = new Date(Date.UTC(baseDate.getFullYear(), baseDate.getMonth(), baseDate.getDate() + 2, 0, 0, 0, 0));
        await governancePage.recordPropertiesSidebar.datePicker.setDate(futureDate);
        await governancePage.datePickerActions.okButton.click();
        await governancePage.recordPropertiesSidebar.saveButton.click();
        await governancePage.searchResults.tableSkeletonLoader.waitFor({ state: 'visible' });
        await governancePage.searchResults.resetButtonLocator.click();
        await governancePage.modifierFilter.modifierFilterLocator.click();
        await governancePage.multiSelectionFilter.matSelectionList.getCheckboxByLabel(creatorAndModifierName).click();
        await governancePage.overlayActions.applyButton.click();
        await governancePage.searchResults.changePageSize('100');
        const recordExistsAfterModify = await governancePage.recordList.isRecordVisibleAcrossPages(uploadedFileTitle);

        expect.soft(recordExistsAfterModify).toBe(true);
        await expect(governancePage.recordList.getStatusCellByRow(uploadedFileTitle)).toContainText(statusReady);
    });
});
