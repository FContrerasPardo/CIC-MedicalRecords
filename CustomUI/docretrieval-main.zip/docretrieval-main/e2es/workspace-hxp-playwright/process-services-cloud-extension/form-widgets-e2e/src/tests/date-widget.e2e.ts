/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { getUserState, HXP_APPS, ProcessInstanceDataEntry } from '@alfresco-dbp/playwright/shared';
import { expect, test } from '@hxp/playwright/workspace-hxp';

test.describe('Date widget', () => {
    test.use({ storageState: getUserState('hruser') });

    const { processes } = HXP_APPS.SYS_WORKSPACE;
    let processInstance: ProcessInstanceDataEntry;

    test.beforeEach(async ({ taskDetailsPage, runtimeBundleServiceHrUser }, workerInfo) => {
        await taskDetailsPage.refreshUserState('hruser', workerInfo.project.use);
        ({ entry: processInstance } = await runtimeBundleServiceHrUser.processInstance.startProcess(
            processes.dynamicDateRangeProcess.processDefinitionKey,
            { name: processes.dynamicDateRangeProcess.processName }
        ));

        const userTasks = await runtimeBundleServiceHrUser.processInstance.waitAndGetTasksByProcessInstanceId(processInstance.id);

        await taskDetailsPage.navigate({ query: `/${userTasks[0].entry.id}`, waitUntil: 'load' });
    });

    test.afterEach(async ({ runtimeBundleServiceHrUser }) => {
        await runtimeBundleServiceHrUser.processInstance.deleteProcessesIfExist(processInstance.id);
    });

    test(`[XAT-18322] Should be able to set the date only within the dynamic date range window`, async ({ taskDetailsPage }) => {
        const { dateWidget } = processes.dynamicDateRangeProcess.form.formWidgets;
        const todaysDate = new Date();

        const allowedFutureDate = new Date(todaysDate);
        allowedFutureDate.setDate(todaysDate.getDate() + 3);

        const allowedPastDate = new Date(todaysDate);
        allowedPastDate.setDate(todaysDate.getDate() - 2);

        const disallowedFutureDate = new Date(todaysDate);
        disallowedFutureDate.setDate(todaysDate.getDate() + 4);

        const disallowedPastDate = new Date(todaysDate);
        disallowedPastDate.setDate(todaysDate.getDate() - 3);

        await test.step('Set allowed dates in the future and in the past', async () => {
            await taskDetailsPage.taskForm.getDatePickerByWidgetIdLocator(dateWidget).click();
            await taskDetailsPage.taskForm.datepicker.setDate(allowedFutureDate);
            const formattedFutureDate = allowedFutureDate.toISOString().split('T')[0];

            await expect.soft(taskDetailsPage.taskForm.getFieldInputByIdLocator(dateWidget)).toHaveValue(formattedFutureDate);

            await taskDetailsPage.taskForm.getDatePickerByWidgetIdLocator(dateWidget).click();
            await taskDetailsPage.taskForm.datepicker.setDate(allowedPastDate);
            const formattedPastDate = allowedPastDate.toISOString().split('T')[0];

            await expect.soft(taskDetailsPage.taskForm.getFieldInputByIdLocator(dateWidget)).toHaveValue(formattedPastDate);
        });

        await test.step('Try to set dates outside of the range', async () => {
            await taskDetailsPage.taskForm.getFieldInputByIdLocator(dateWidget).clear();

            await taskDetailsPage.taskForm.getDatePickerByWidgetIdLocator(dateWidget).click();
            await taskDetailsPage.taskForm.datepicker.setDate(disallowedFutureDate);
            await taskDetailsPage.taskForm.datepicker.closeOverlays();

            await expect.soft(taskDetailsPage.taskForm.getFieldInputByIdLocator(dateWidget)).toHaveValue('');

            await taskDetailsPage.taskForm.getDatePickerByWidgetIdLocator(dateWidget).click();
            await taskDetailsPage.taskForm.datepicker.setDate(disallowedPastDate);
            await taskDetailsPage.taskForm.datepicker.closeOverlays();

            await expect(taskDetailsPage.taskForm.getFieldInputByIdLocator(dateWidget)).toHaveValue('');
        });
    });
});
