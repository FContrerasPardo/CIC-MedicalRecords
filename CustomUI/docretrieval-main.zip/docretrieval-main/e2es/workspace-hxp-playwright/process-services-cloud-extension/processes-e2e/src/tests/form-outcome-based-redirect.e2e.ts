/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { getUserState, ProcessInstanceDataEntry, HXP_APPS, TestFlags } from '@alfresco-dbp/playwright/shared';
import { test, expect, WorkspaceHxpFeatureFlagNames } from '@hxp/playwright/workspace-hxp';

test.use({ storageState: getUserState('hruser') });
test.describe('Form outcome based redirects', () => {
    const { formBasedRedirect, redirectAfterSubmitLanding, redirectAfterSubmitPrevious, redirectAfterSubmitQuery, redirectAfterSubmitURL } =
        HXP_APPS.SYS_WORKSPACE.processes;
    let currentProcessInstance: ProcessInstanceDataEntry;

    test.beforeAll(async ({ skipOrExecuteTestBasedOnFlagStatus }) => {
        await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.StudioUserTaskRedirectBasedOnFormOutcome, 'new-functionality');
    });

    test.beforeEach(async ({ processPage, page }) => {
        await processPage.navigate();
        await page.waitForLoadState('load');
    });

    test.afterEach(async ({ runtimeBundleServiceHrUser }) => {
        await runtimeBundleServiceHrUser.processInstance.deleteProcessesIfExist(currentProcessInstance?.id);
    });

    const startEventTests = [
        {
            title: '[XAT-18475] Verify Previous page redirect option from Form Outcomes on Start Event',
            outcome: 'oc1',
            expectedURL: 'process-list-cloud',
        },
        {
            title: '[XAT-18476] Verify Landing page redirect option from Form Outcomes on Start Event',
            outcome: 'oc2',
            expectedURL: 'display-message',
        },
        {
            title: '[XAT-18477] Verify URL (static) redirect option from Form Outcomes on Start Event',
            outcome: 'oc3',
            expectedURL: 'hyland.com',
        },
    ];
    for (const { title, outcome, expectedURL } of startEventTests) {
        test(`${title}`, { tag: [TestFlags.UnderFF] }, async ({ startProcessPage, page }) => {
            await test.step('Open Start Process page', async () => {
                await startProcessPage.navigate({ query: `?process=${formBasedRedirect.processName}`, waitUntil: 'load' });
                await startProcessPage.taskForm.waitForRootElement();
            });

            await test.step('Select Form Based Outcome', async () => {
                const response = await startProcessPage.taskForm.clickFormOutcomeAndWaitForSubmitResponse(outcome);
                currentProcessInstance = { id: response.id } as ProcessInstanceDataEntry;
                await page.waitForEvent('framenavigated');
            });

            await test.step('Verify redirect', async () => {
                await expect(page.url()).toContain(expectedURL);
            });
        });
    }

    const startEventQueryTest = {
        outcome: 'oc4',
        expectedURL: 'hyland.com',
        redirectParam: `${encodeURIComponent('https://www.hyland.com')}`,
    };
    test(
        `[XAT-18478] Verify URL (query string) redirect option from Form Outcomes on Start Event`,
        { tag: [TestFlags.UnderFF] },
        async ({ startProcessPage, page }) => {
            await test.step('Open Start Process page', async () => {
                await startProcessPage.navigate({
                    query: `?process=${formBasedRedirect.processName}&redirect=${startEventQueryTest.redirectParam}`,
                    waitUntil: 'load',
                });
                await startProcessPage.taskForm.waitForRootElement();
            });

            await test.step('Select Form Based Outcome', async () => {
                const response = await startProcessPage.taskForm.clickFormOutcomeAndWaitForSubmitResponse(startEventQueryTest.outcome);
                currentProcessInstance = { id: response.id } as ProcessInstanceDataEntry;
                await page.waitForEvent('framenavigated');
            });

            await test.step('Verify redirect', async () => {
                await expect(page.url()).toContain(startEventQueryTest.expectedURL);
            });
        }
    );

    const userTaskTests = [
        {
            title: '[XAT-18479] Verify Previous page redirect option from Form Outcomes on User Task Event',
            outcome: 'oc1',
            expectedURL: 'process-list-cloud',
        },
        {
            title: '[XAT-18480] Verify Landing page redirect option from Form Outcomes on User Task Event',
            outcome: 'oc2',
            expectedURL: 'display-message',
        },
        {
            title: '[XAT-18481] Verify URL (static) redirect option from Form Outcomes on User Task Event',
            outcome: 'oc3',
            expectedURL: 'hyland.com',
        },
    ];
    for (const { title, outcome, expectedURL } of userTaskTests) {
        test(`${title}`, { tag: [TestFlags.UnderFF] }, async ({ taskDetailsPage, page, runtimeBundleServiceHrUser }) => {
            await test.step('Start process and open User Task', async () => {
                const { entry: processInstance } = await runtimeBundleServiceHrUser.processInstance.startProcess(
                    formBasedRedirect.processDefinitionKey,
                    {
                        name: formBasedRedirect.processName,
                    }
                );
                currentProcessInstance = { id: processInstance.id } as ProcessInstanceDataEntry;

                const userTask = await runtimeBundleServiceHrUser.processInstance.waitAndGetTasksByProcessInstanceId(currentProcessInstance.id);
                await taskDetailsPage.navigate({ query: `/${userTask[0].entry.id}`, waitUntil: 'load' });
            });

            await test.step('Select Form Based Outcome', async () => {
                await taskDetailsPage.taskForm.getFormOutcomeButtonByName(outcome).click();
                await page.waitForEvent('framenavigated');
            });

            await test.step('Verify redirect', async () => {
                await expect(page.url()).toContain(expectedURL);
            });
        });
    }

    const userTaskEventQueryTest = {
        outcome: 'oc4',
        expectedURL: 'hyland.com',
        redirectParam: `${encodeURIComponent('https://www.hyland.com')}`,
    };
    test(
        `[XAT-18482] Verify URL (query string) redirect option from Form Outcomes on User Task Event`,
        { tag: [TestFlags.UnderFF] },
        async ({ taskDetailsPage, page, runtimeBundleServiceHrUser }) => {
            await test.step('Start process and open User Task', async () => {
                const { entry: processInstance } = await runtimeBundleServiceHrUser.processInstance.startProcess(
                    formBasedRedirect.processDefinitionKey,
                    {
                        name: formBasedRedirect.processName,
                    }
                );
                currentProcessInstance = { id: processInstance.id } as ProcessInstanceDataEntry;

                const userTask = await runtimeBundleServiceHrUser.processInstance.waitAndGetTasksByProcessInstanceId(currentProcessInstance.id);
                await taskDetailsPage.navigate({
                    query: `/${userTask[0].entry.id}?redirect=${userTaskEventQueryTest.redirectParam}`,
                    waitUntil: 'load',
                });
            });

            await test.step('Select Form Based Outcome', async () => {
                await taskDetailsPage.taskForm.getFormOutcomeButtonByName(userTaskEventQueryTest.outcome).click();
                await page.waitForEvent('framenavigated');
            });

            await test.step('Verify redirect', async () => {
                await expect(page.url()).toContain(userTaskEventQueryTest.expectedURL);
            });
        }
    );

    const redirectAfterSubmitTests = [
        {
            title: '[XAT-18542] Verify Previous page redirect option from "Redirect after submission" setting on a custom form outcome',
            expectedURL: 'process-list-cloud',
            process: redirectAfterSubmitPrevious,
        },
        {
            title: '[XAT-18543] Verify Landing page redirect option from "Redirect after submission" setting on a custom form outcome',
            expectedURL: 'display-message',
            process: redirectAfterSubmitLanding,
        },
        {
            title: '[XAT-18544] Verify URL (static) redirect option from "Redirect after submission" setting on a custom form outcome',
            expectedURL: 'hyland.com',
            process: redirectAfterSubmitURL,
        },
    ];
    const formOutcomeName = 'oc1';
    for (const { title, expectedURL, process } of redirectAfterSubmitTests) {
        test(`${title}`, { tag: [TestFlags.UnderFF] }, async ({ startProcessPage, page }) => {
            await test.step('Open Start Process page', async () => {
                await startProcessPage.navigate({ query: `?process=${process.processName}`, waitUntil: 'load' });
                await startProcessPage.taskForm.waitForRootElement();
            });

            await test.step('Select Form Based Outcome', async () => {
                const response = await startProcessPage.taskForm.clickFormOutcomeAndWaitForSubmitResponse(formOutcomeName);
                currentProcessInstance = { id: response.id } as ProcessInstanceDataEntry;
                await page.waitForEvent('framenavigated');
            });

            await test.step('Verify redirect', async () => {
                await expect(page.url()).toContain(expectedURL);
            });
        });
    }

    const redirectAfterSubmitQueryTest = {
        expectedURL: 'hyland.com',
        process: redirectAfterSubmitQuery,
        redirectParam: `${encodeURIComponent('https://www.hyland.com')}`,
    };
    test(
        `[XAT-18545] Verify URL (query string) redirect option from "Redirect after submission" setting on a custom form outcome`,
        { tag: [TestFlags.UnderFF] },
        async ({ startProcessPage, page }) => {
            await test.step('Open Start Process page', async () => {
                await startProcessPage.navigate({
                    query: `?process=${redirectAfterSubmitQueryTest.process.processName}&redirect=${redirectAfterSubmitQueryTest.redirectParam}`,
                    waitUntil: 'load',
                });
                await startProcessPage.taskForm.waitForRootElement();
            });

            await test.step('Select Form Based Outcome', async () => {
                const response = await startProcessPage.taskForm.clickFormOutcomeAndWaitForSubmitResponse(formOutcomeName);
                currentProcessInstance = { id: response.id } as ProcessInstanceDataEntry;
                await page.waitForEvent('framenavigated');
            });

            await test.step('Verify redirect', async () => {
                await expect(page.url()).toContain(redirectAfterSubmitQueryTest.expectedURL);
            });
        }
    );
});
