/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { of, Subject } from 'rxjs';
import { By } from '@angular/platform-browser';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { jestMocks } from '@hxp/workspace-hxp/shared/testing';
import { DOCUMENT_PROPERTIES_SERVICE, DocumentService, HxpNotificationService } from '@alfresco/adf-hx-content-services/services';
import { CardViewItem, CardViewUpdateService, NoopTranslateModule, CardViewTextItemModel } from '@alfresco/adf-core';
import { provideMockFeatureFlags } from '@alfresco/adf-core/feature-flags';
import { HxpMetadataSidebarComponent } from './hxp-metadata-sidebar.component';
import { MetadataSidebarService } from './hxp-metadata-sidebar.service';
import { TestbedHarnessEnvironment } from '@angular/cdk/testing/testbed';
import { MatProgressSpinnerHarness } from '@angular/material/progress-spinner/testing';
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { MetadataSidebarContentComponent } from '../metadata-sidebar-content/metadata-sidebar-content.component';
import { HxpMetadataSidebarAdditionalInfoComponent } from '../metadata-sidebar-additional-info/hxp-metadata-sidebar-additional-info.component';
import { MatTabGroupHarness } from '@angular/material/tabs/testing';
import { MatButtonHarness } from '@angular/material/button/testing';
import { MatDialog } from '@angular/material/dialog';

@Component({
    selector: 'hxp-metadata-sidebar-content',
    template: '',
    standalone: true,
})
class MockMetadataSidebarContentComponent {
    @Input() title!: string;
    @Input() properties$!: any;
    private _editMode = false;
    @Input()
    get editMode(): boolean {
        return this._editMode;
    }
    set editMode(editMode: boolean) {
        this._editMode = editMode;
        this.editModeChange.emit(editMode);
    }
    @Output() editModeChange = new EventEmitter<boolean>();
    @Input() propertyUpdated!: any;
    @Input() editable = true;
    @Input() useChipsForMultiValueProperty = false;
    @Input() document!: any;
    @Input() properties!: any;
    @Input() displayLabelForChips!: string;
}

@Component({
    selector: 'hxp-metadata-sidebar-additional-info',
    template: '',
    standalone: true,
})
class MockMetadataSidebarAdditionalInfoComponent {
    @Input() nonEditableSystemProperties: CardViewItem[] = [];
}

describe('HxpMetadataSidebarComponent', () => {
    let component: HxpMetadataSidebarComponent;
    let fixture: ComponentFixture<HxpMetadataSidebarComponent>;

    const createMockItem = (props: any) => {
        const item = new CardViewTextItemModel({
            ...props,
            value: of(props.value),
            displayValue: of(props.displayValue ?? props.value),
        });
        return item as unknown as CardViewItem;
    };

    const editableItems: CardViewItem[] = [
        createMockItem({
            key: 'sys_title',
            label: 'Title',
            value: 'Title',
            editable: true,
        }),
    ];
    const nonEditableItems: CardViewItem[] = [
        createMockItem({
            key: 'sys_created',
            label: 'Created',
            value: '2023-01-01',
            editable: false,
        }),
    ];
    const customItems: CardViewItem[] = [
        createMockItem({
            key: 'custom_field',
            label: 'Custom Field',
            value: 'Custom Value',
            editable: false,
        }),
    ];

    const customProperties$ = new Subject<CardViewItem[]>();
    const nonEditableSystemProperties$ = new Subject<CardViewItem[]>();

    const mockMetadataSidebarService = {
        getEditableSystemPropertiesFromDocument: jest.fn().mockReturnValue(of(editableItems)),
        getNonEditableSystemPropertiesFromDocument: jest.fn().mockReturnValue(nonEditableSystemProperties$.asObservable()),
        getCustomProperties: jest.fn().mockReturnValue(customProperties$.asObservable()),
    };

    const documentUpdatedSubject = new Subject<{ document: any }>();
    let getDocumentByIdSubject: Subject<any>;

    const mockDocumentService = {
        documentUpdated$: documentUpdatedSubject.asObservable(),
        getDocumentById: jest.fn(),
        updateDocument: jest.fn().mockReturnValue(of({ ...jestMocks.fileDocument, sys_title: 'New Title' })),
    };

    const mockNotificationService = {
        openSnackBar: jest.fn(),
    };

    const mockCardViewUpdateService = {
        updated$: new Subject<any>(),
        itemUpdated$: new Subject<any>(),
        clicked$: new Subject<any>(),
        update: jest.fn(),
        updateItem: jest.fn(),
        click: jest.fn(),
    };

    const mockDocumentPropertiesService = {
        getRequiredProperties: jest.fn().mockReturnValue(['sys_title']),
        propertyType: jest.fn().mockReturnValue(undefined),
        extractCustomSchemaFields: jest.fn().mockReturnValue(of({ custom_field: '' })),
    };

    beforeEach(async () => {
        getDocumentByIdSubject = new Subject<any>();
        mockDocumentService.getDocumentById.mockReturnValue(getDocumentByIdSubject.asObservable());
        await TestBed.configureTestingModule({
            imports: [HxpMetadataSidebarComponent, NoopTranslateModule],
            providers: [
                { provide: DOCUMENT_PROPERTIES_SERVICE, useValue: mockDocumentPropertiesService },
                { provide: DocumentService, useValue: mockDocumentService },
                { provide: HxpNotificationService, useValue: mockNotificationService },
                { provide: CardViewUpdateService, useValue: mockCardViewUpdateService },
                { provide: MetadataSidebarService, useValue: mockMetadataSidebarService },
                provideMockFeatureFlags({
                    'cic-workspace-new-metadata-panel': false,
                }),
            ],
        })
            .overrideComponent(HxpMetadataSidebarComponent, {
                remove: {
                    imports: [MetadataSidebarContentComponent, HxpMetadataSidebarAdditionalInfoComponent],
                },
                add: {
                    imports: [MockMetadataSidebarContentComponent, MockMetadataSidebarAdditionalInfoComponent],
                },
            })
            .compileComponents();
        fixture = TestBed.createComponent(HxpMetadataSidebarComponent);
        component = fixture.componentInstance;
        customProperties$.next(customItems);
        nonEditableSystemProperties$.next(nonEditableItems);
        customProperties$.next(customItems);
        fixture.detectChanges();
    });

    it('should load properties when document input is set', () => {
        component.document = jestMocks.fileDocument;
        component.ngOnChanges();

        getDocumentByIdSubject.next(jestMocks.fileDocument);

        expect(mockDocumentService.getDocumentById).toHaveBeenCalledWith(jestMocks.fileDocument.sys_id);
        expect(mockMetadataSidebarService.getEditableSystemPropertiesFromDocument).toHaveBeenCalled();
        expect(mockMetadataSidebarService.getNonEditableSystemPropertiesFromDocument).toHaveBeenCalled();
        expect(mockMetadataSidebarService.getCustomProperties).toHaveBeenCalled();
        expect(mockDocumentPropertiesService.extractCustomSchemaFields).toHaveBeenCalledWith(jestMocks.fileDocument.sys_primaryType);

        fixture.detectChanges();

        const contentElement = fixture.debugElement.query(By.css('hxp-metadata-sidebar-content'));

        expect(contentElement).toBeTruthy();
    });

    it('should reload properties after edit on documentUpdated$ for same document id', () => {
        component.document = jestMocks.fileDocument;
        component.ngOnChanges();

        jest.clearAllMocks();
        documentUpdatedSubject.next({ document: jestMocks.fileDocument });

        getDocumentByIdSubject.next(jestMocks.fileDocument);

        expect(mockMetadataSidebarService.getEditableSystemPropertiesFromDocument).toHaveBeenCalled();
        expect(mockMetadataSidebarService.getNonEditableSystemPropertiesFromDocument).toHaveBeenCalled();
        expect(mockMetadataSidebarService.getCustomProperties).toHaveBeenCalled();
        expect(mockDocumentPropertiesService.extractCustomSchemaFields).toHaveBeenCalledWith(jestMocks.fileDocument.sys_primaryType);
    });

    it('should activate edit mode on edit button click', () => {
        component.document = jestMocks.fileDocument;
        component.editable = true;
        fixture.detectChanges();

        let editButton = fixture.debugElement.query(By.css('.hxp-property-edit-button.hxp-primary-button'));

        expect(editButton).toBeTruthy();

        editButton.nativeElement.click();
        fixture.detectChanges();

        const saveButton = fixture.debugElement.query(By.css('.hxp-save-properties-button'));
        editButton = fixture.debugElement.query(By.css('.hxp-property-edit-button.hxp-primary-button'));

        expect(saveButton).toBeTruthy();
        expect(editButton).toBeFalsy();
    });

    it('should exit edit mode on cancel button click', () => {
        component.document = jestMocks.fileDocument;
        component.editable = true;
        fixture.detectChanges();

        let editButton = fixture.debugElement.query(By.css('.hxp-property-edit-button.hxp-primary-button'));

        expect(editButton).toBeTruthy();

        editButton.nativeElement.click();
        fixture.detectChanges();

        let cancelButton = fixture.debugElement.query(By.css('.hxp-text-button'));

        expect(cancelButton).toBeTruthy();

        cancelButton.nativeElement.click();
        fixture.detectChanges();

        editButton = fixture.debugElement.query(By.css('.hxp-property-edit-button.hxp-primary-button'));
        cancelButton = fixture.debugElement.query(By.css('.hxp-text-button'));

        expect(editButton).toBeTruthy();
        expect(cancelButton).toBeFalsy();
    });

    it('should save properties on save button click', async () => {
        component.document = jestMocks.fileDocument;
        component.editable = true;
        component.ngOnChanges();
        fixture.detectChanges();

        const editButton = fixture.debugElement.query(By.css('.hxp-property-edit-button.hxp-primary-button'));
        editButton.nativeElement.click();
        fixture.detectChanges();

        mockCardViewUpdateService.itemUpdated$.next({
            target: { key: 'sys_title', value: 'New Title' },
            changed: { sys_title: 'New Title' },
        });

        await Promise.resolve();
        fixture.detectChanges();

        const loader = TestbedHarnessEnvironment.loader(fixture);
        const saveButton = await loader.getHarness(MatButtonHarness.with({ selector: '.hxp-save-properties-button' }));

        expect(await saveButton.isDisabled()).toBe(false);

        await saveButton.click();

        expect(mockDocumentService.updateDocument).toHaveBeenCalledWith(jestMocks.fileDocument.sys_id, { sys_title: 'New Title' });
    });

    it('should emit closePropertySidebar event when close button clicked', () => {
        jest.spyOn(component.closePropertySidebar, 'emit');
        fixture.detectChanges();
        const btn = fixture.debugElement.query(By.css('.hxp-metadata-sidebar-close-button'));

        expect(btn).toBeTruthy();

        btn.nativeElement.click();

        expect(component.closePropertySidebar.emit).toHaveBeenCalled();
    });

    it('shows Edit button when editable', () => {
        component.editable = false;
        fixture.detectChanges();

        let editButton = fixture.debugElement.query(By.css('.hxp-property-edit-button.hxp-primary-button'));

        expect(editButton).toBeFalsy();

        component.editable = true;
        fixture.detectChanges();

        editButton = fixture.debugElement.query(By.css('.hxp-property-edit-button.hxp-primary-button'));

        expect(editButton).toBeTruthy();
    });

    it('shows Save disabled until modified & valid', async () => {
        component.editable = true;
        component.ngOnChanges();

        const editButton = fixture.debugElement.query(By.css('.hxp-property-edit-button.hxp-primary-button'));
        editButton.nativeElement.click();
        fixture.detectChanges();

        const loader = TestbedHarnessEnvironment.loader(fixture);
        const saveButton = await loader.getHarness(MatButtonHarness.with({ selector: '.hxp-save-properties-button' }));

        expect(await saveButton.isDisabled()).toBe(true);

        mockCardViewUpdateService.itemUpdated$.next({
            target: { key: 'sys_title', value: 'New Title' },
            changed: { sys_title: 'New Title' },
        });

        await Promise.resolve();
        fixture.detectChanges();

        expect(await saveButton.isDisabled()).toBe(false);
    });

    it('should show spinner when propertyLoading is true', async () => {
        component.document = jestMocks.fileDocument;
        component.ngOnChanges();
        fixture.detectChanges();

        const loader = TestbedHarnessEnvironment.loader(fixture);
        let spinner = await loader.getHarnessOrNull(MatProgressSpinnerHarness);

        expect(spinner).toBeTruthy();

        getDocumentByIdSubject.next(jestMocks.fileDocument);
        getDocumentByIdSubject.complete();

        spinner = await loader.getHarnessOrNull(MatProgressSpinnerHarness);
        expect(spinner).toBeNull();
    });

    it('renders Properties tab when custom properties exist', async () => {
        component.document = jestMocks.fileDocument;
        customProperties$.next([]);
        component.ngOnChanges();
        await fixture.whenStable();

        getDocumentByIdSubject.next(jestMocks.fileDocument);

        const loader = TestbedHarnessEnvironment.loader(fixture);
        const tabGroups = await loader.getAllHarnesses(MatTabGroupHarness);

        let tabs = await tabGroups[0].getTabs();

        expect(tabs.length).toBe(0);

        customProperties$.next([
            createMockItem({
                key: 'c1',
                label: 'Custom One',
                value: 'val',
            }),
        ]);
        fixture.detectChanges();
        await fixture.whenStable();

        tabs = await tabGroups[0].getTabs();

        expect(tabs.length).toBe(1);

        await tabs[0].select();
        fixture.detectChanges();
        await fixture.whenStable();

        const tabLabels = await Promise.all(tabs.map((tab) => tab.getLabel()));

        expect(tabLabels).toContain('DOCUMENT.METADATA.TABS.PROPERTIES');
    });

    it('should make sidebar non-editable when update is in progress', async () => {
        component.document = jestMocks.fileDocument;
        component.editable = true;
        component.ngOnChanges();
        fixture.detectChanges();

        const editButton = fixture.debugElement.query(By.css('.hxp-property-edit-button.hxp-primary-button'));
        editButton.nativeElement.click();
        fixture.detectChanges();
        await fixture.whenStable();

        getDocumentByIdSubject.next(jestMocks.fileDocument);

        mockCardViewUpdateService.itemUpdated$.next({
            target: { key: 'sys_title', value: 'New Title' },
            changed: { sys_title: 'New Title' },
        });
        await Promise.resolve();
        fixture.detectChanges();

        let sidebarContent = fixture.debugElement.query(By.directive(MockMetadataSidebarContentComponent));
        expect(sidebarContent.componentInstance.editable).toBe(true);

        const loader = TestbedHarnessEnvironment.loader(fixture);
        const saveButton = await loader.getHarness(MatButtonHarness.with({ selector: '.hxp-save-properties-button' }));
        await saveButton.click();

        sidebarContent = fixture.debugElement.query(By.directive(MockMetadataSidebarContentComponent));
        expect(sidebarContent.componentInstance.editable).toBe(false);
    });

    it('should disable update and cancel buttons when update is in progress', async () => {
        component.document = jestMocks.fileDocument;
        component.editable = true;
        component.ngOnChanges();
        fixture.detectChanges();

        const editButton = fixture.debugElement.query(By.css('.hxp-property-edit-button.hxp-primary-button'));
        editButton.nativeElement.click();
        fixture.detectChanges();

        mockCardViewUpdateService.itemUpdated$.next({
            target: { key: 'sys_title', value: 'New Title' },
            changed: { sys_title: 'New Title' },
        });
        await Promise.resolve();
        fixture.detectChanges();

        const updatePropertySubject = new Subject<any>();
        mockDocumentService.updateDocument.mockReturnValue(updatePropertySubject.asObservable());

        const loader = TestbedHarnessEnvironment.loader(fixture);
        const saveButton = await loader.getHarness(MatButtonHarness.with({ selector: '.hxp-save-properties-button' }));
        const cancelButton = await loader.getHarness(MatButtonHarness.with({ selector: '.hxp-text-button' }));

        await saveButton.click();
        fixture.detectChanges();

        expect(await saveButton.isDisabled()).toBe(true);
        expect(await cancelButton.isDisabled()).toBe(true);
    });

    it('should render additional-info component when non-editable properties exist', async () => {
        component.document = jestMocks.fileDocument;
        nonEditableSystemProperties$.next([]);
        component.ngOnChanges();

        getDocumentByIdSubject.next(jestMocks.fileDocument);

        fixture.detectChanges();
        await fixture.whenStable();

        const loader = TestbedHarnessEnvironment.loader(fixture);
        const tabGroups = await loader.getAllHarnesses(MatTabGroupHarness);

        let tabs = await tabGroups[0].getTabs();

        expect(tabs.length).toBe(0);

        const createdItem = createMockItem({
            key: 'sys_created',
            label: 'Created',
            value: '2025-10-15',
            editable: false,
        });

        const modifiedItem = createMockItem({
            key: 'sys_modified',
            label: 'Last Modified',
            value: '2025-10-16',
            editable: false,
        });

        nonEditableSystemProperties$.next([createdItem, modifiedItem]);

        fixture.detectChanges();
        await fixture.whenStable();

        tabs = await tabGroups[0].getTabs();

        expect(tabs.length).toBe(1);

        const tabLabels = await Promise.all(tabs.map((tab) => tab.getLabel()));

        expect(tabLabels).toContain('DOCUMENT.METADATA.TABS.ADDITIONAL_INFORMATION');

        await tabs[0].select();
        fixture.detectChanges();
        await fixture.whenStable();

        const sidebarContentElements = fixture.debugElement.queryAll(By.directive(MockMetadataSidebarAdditionalInfoComponent));

        expect(sidebarContentElements.length).toBeGreaterThan(0);

        const additionalInfoComponent = sidebarContentElements[0].componentInstance as MockMetadataSidebarAdditionalInfoComponent;

        expect(additionalInfoComponent).toBeTruthy();
    });

    it('should prevent multiple reloads after property update for same document id', () => {
        component.document = jestMocks.fileDocument;
        component.ngOnChanges();
        fixture.detectChanges();

        jest.clearAllMocks();
        documentUpdatedSubject.next({ document: jestMocks.fileDocument });
        fixture.detectChanges();

        expect(mockMetadataSidebarService.getEditableSystemPropertiesFromDocument).toHaveBeenCalledTimes(1);
        expect(mockMetadataSidebarService.getNonEditableSystemPropertiesFromDocument).toHaveBeenCalledTimes(1);
        expect(mockMetadataSidebarService.getCustomProperties).toHaveBeenCalledTimes(1);
        expect(mockDocumentPropertiesService.extractCustomSchemaFields).toHaveBeenCalledTimes(1);
    });

    it('should show cancel dialog when cancel button is clicked with pending changes', () => {
        component.document = jestMocks.fileDocument;
        component.editable = true;
        fixture.detectChanges();

        const editButton = fixture.debugElement.query(By.css('.hxp-property-edit-button.hxp-primary-button'));
        editButton.nativeElement.click();
        fixture.detectChanges();

        mockCardViewUpdateService.itemUpdated$.next({
            target: { key: 'sys_title', value: 'New Title' },
            changed: { sys_title: 'New Title' },
        });
        fixture.detectChanges();

        const dialog = TestBed.inject(MatDialog);
        const openDialogSpy = jest.spyOn(dialog, 'open');

        const cancelButton = fixture.debugElement.query(By.css('.hxp-text-button'));
        cancelButton.nativeElement.click();
        fixture.detectChanges();

        expect(openDialogSpy).toHaveBeenCalled();
    });

    it('should show cancel dialog when close is clicked while update is in progress', () => {
        component.document = jestMocks.fileDocument;
        component.editable = true;
        fixture.detectChanges();

        const editButton = fixture.debugElement.query(By.css('.hxp-property-edit-button.hxp-primary-button'));
        editButton.nativeElement.click();
        fixture.detectChanges();
        mockCardViewUpdateService.itemUpdated$.next({
            target: { key: 'sys_title', value: 'New Title' },
            changed: { sys_title: 'New Title' },
        });
        fixture.detectChanges();

        const dialog = TestBed.inject(MatDialog);
        const openDialogSpy = jest.spyOn(dialog, 'open');

        const closeButton = fixture.debugElement.query(By.css('.hxp-metadata-sidebar-close-button'));
        closeButton.nativeElement.click();
        fixture.detectChanges();

        expect(openDialogSpy).toHaveBeenCalled();
    });

    it('should NOT show cancel dialog when close is clicked after update is complete', async () => {
        component.document = jestMocks.fileDocument;
        component.editable = true;
        fixture.detectChanges();

        const editButton = fixture.debugElement.query(By.css('.hxp-property-edit-button.hxp-primary-button'));
        editButton.nativeElement.click();

        mockCardViewUpdateService.itemUpdated$.next({
            target: { key: 'sys_title', value: 'New Title' },
            changed: { sys_title: 'New Title' },
        });
        fixture.detectChanges();

        const dialog = TestBed.inject(MatDialog);
        const openDialogSpy = jest.spyOn(dialog, 'open');

        const updatePropertySubject = new Subject<any>();
        mockDocumentService.updateDocument.mockReturnValue(updatePropertySubject.asObservable());

        const loader = TestbedHarnessEnvironment.loader(fixture);
        const saveButton = await loader.getHarness(MatButtonHarness.with({ selector: '.hxp-save-properties-button' }));
        await saveButton.click();

        updatePropertySubject.next({ ...jestMocks.fileDocument, sys_title: 'New Title' });
        updatePropertySubject.complete();
        await fixture.whenStable();

        const closeButton = fixture.debugElement.query(By.css('.hxp-metadata-sidebar-close-button'));
        closeButton.nativeElement.click();

        expect(openDialogSpy).not.toHaveBeenCalled();
    });
});
