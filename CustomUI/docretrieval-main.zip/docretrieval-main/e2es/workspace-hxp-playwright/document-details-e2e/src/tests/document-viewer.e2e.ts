/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { getUserState, timeouts, FileProperties, files, TestFlags } from '@alfresco-dbp/playwright/shared';
import { ViewerTypes, expect, test, WorkspaceHxpFeatureFlagNames } from '@hxp/playwright/workspace-hxp';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { format } from 'date-fns';

let parentFolder: Document;

test.use({ storageState: getUserState('hruser') });

test.beforeEach(async ({ hxprApi }) => {
    parentFolder = await hxprApi.documentServiceApi.createFolderWithPermissions('Document Details', 'document-viewer', 'hr');
});

test.afterEach(async ({ hxprApi }) => hxprApi.documentServiceApi.teardown());

test.describe('Document Viewer Navigation', async () => {
    test(`[C697269] User should be able to see the document preview`, async ({ contentBrowserPage, hxprApi }) => {
        const uploadedFile = await hxprApi.uploadServiceApi.uploadFile(files.pdfFile, parentFolder.sys_id);

        await contentBrowserPage.navigateToDocument(parentFolder.sys_id);
        await contentBrowserPage.mainContentContainer.getDocByTestId(uploadedFile.sys_title).click();

        await expect(contentBrowserPage.documentViewer.adfViewer).toBeVisible();
    });

    const testScenarios: {
        testID: string;
        testName: string;
        file: FileProperties;
        viewerType: ViewerTypes;
    }[] = [
        { testID: 'C697261', testName: 'a PDF', file: files.pdfFile, viewerType: ViewerTypes.Pdf },
        { testID: 'C697262', testName: 'an image', file: files.jpgFile, viewerType: ViewerTypes.Img },
        { testID: 'XAT-417', testName: 'an unknown format', file: files.invalidFile, viewerType: ViewerTypes.UnknownFormat },
        { testID: 'C699497', testName: 'a Text', file: files.txtFile, viewerType: ViewerTypes.Txt },
    ];

    for (const scenario of testScenarios) {
        test(`[${scenario.testID}] Correct internal viewer is loaded when user opens ${scenario.testName} file`, async ({
            contentBrowserPage,
            hxprApi,
        }) => {
            const errorMessage = `Couldn't load preview. Unsupported file type or loading error. Please try refreshing the page.`;
            const uploadedFile = await hxprApi.uploadServiceApi.uploadFile(scenario.file, parentFolder.sys_id);

            await contentBrowserPage.navigateToDocument(uploadedFile.sys_id);

            await expect(contentBrowserPage.documentViewer.getViewerByType(scenario.viewerType)).toBeVisible();
            if (scenario.testName === 'an unknown format') {
                await expect(contentBrowserPage.documentViewer.unknownFormatErrorMessage).toContainText(errorMessage);
            }
        });
    }
    const renditionTestScenarios: {
        testID: string;
        testName: string;
        file: FileProperties;
        viewerType: ViewerTypes;
    }[] = [
        { testID: 'C701466', testName: 'a Tiff', file: files.tiffFile, viewerType: ViewerTypes.Tiff },
        { testID: 'C699052', testName: 'a Word', file: files.docFile, viewerType: ViewerTypes.Word },
        { testID: 'XAT-16417', testName: 'an Excel', file: files.xlsFile, viewerType: ViewerTypes.Excel },
        { testID: 'XAT-16419', testName: 'a Powerpoint', file: files.pptFile, viewerType: ViewerTypes.Powerpoint },
    ];

    for (const scenario of renditionTestScenarios) {
        test(`[${scenario.testID}] Doc viewer loaded when user opens ${scenario.testName} file after pdf rendition`, async ({
            contentBrowserPage,
            hxprApi,
        }) => {
            const uploadedFile = await hxprApi.uploadServiceApi.uploadFile(scenario.file, parentFolder.sys_id);

            await contentBrowserPage.navigateToDocument(uploadedFile.sys_id);

            await expect(contentBrowserPage.documentViewer.getViewerByType(scenario.viewerType)).toBeVisible({ timeout: timeouts.extraLarge });
        });
    }

    test(`[C698537] User should be able to close the document viewer and go back to parent folder`, async ({ contentBrowserPage, page, hxprApi }) => {
        const uploadedFile = await hxprApi.uploadServiceApi.uploadFile(files.pdfFile, parentFolder.sys_id);

        await contentBrowserPage.navigateToDocument(uploadedFile.sys_id);
        await contentBrowserPage.documentViewer.closeButton.click();

        expect.soft(page.url()).toContain(parentFolder.sys_id);
        await expect(contentBrowserPage.documentViewer.adfViewer).not.toBeVisible();
    });

    test(`[C698538] Correct file path is visible in the Breadcrumb in the document viewer`, async ({ contentBrowserPage, hxprApi }) => {
        const uploadedFile = await hxprApi.uploadServiceApi.uploadFile(files.pdfFile, parentFolder.sys_id);
        const expectedBreadcrumb = ['Home', parentFolder.sys_title, uploadedFile.sys_title];

        await contentBrowserPage.navigateToDocument(uploadedFile.sys_id);

        const breadcrumbArray = await contentBrowserPage.documentViewer.getBreadcrumbArray();
        expect(breadcrumbArray).toEqual(expectedBreadcrumb);
    });

    test(`${TestFlags.UnderFF} [XAT-420] Correct metadata is visible in the document viewer info panel`, async ({
        contentBrowserPage,
        hxprApi,
        skipOrExecuteTestBasedOnFlagStatus,
    }) => {
        await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.CicWorkspaceNewMetadataPanel, 'new-functionality');

        const { pdfFile } = files;
        const fileSize = '13.02 KB';
        const currentDate = format(new Date(), 'MMM d, yyyy');
        const fileContentType = 'SysFile';
        const { propertiesViewer } = contentBrowserPage.documentViewer;

        const uploadedFile = await hxprApi.uploadServiceApi.uploadFile(pdfFile, parentFolder.sys_id);

        const { firstName, lastName } = uploadedFile.sys_creator;
        const currentUser = `${firstName} ${lastName}`;
        const path = uploadedFile.sys_path;

        await test.step('Open metadata side panel', async () => {
            await contentBrowserPage.navigateToDocument(uploadedFile.sys_id);
            await contentBrowserPage.documentViewer.infoButton.click();

            await expect(propertiesViewer.getChild('')).toBeVisible();
        });

        await test.step('Verify Overview metadata information', async () => {
            await expect.soft(propertiesViewer.sidebarTitleValue).toContainText(uploadedFile.sys_title);
            await expect.soft(propertiesViewer.categoryValue).toContainText(fileContentType);
            await expect.soft(propertiesViewer.titleField).toHaveValue(uploadedFile.sys_title);
            await expect.soft(propertiesViewer.fileNameField).toHaveValue(pdfFile.title);
        });

        await test.step('Verify Additional Information tab metadata', async () => {
            await expect.soft(propertiesViewer.additionalInfoTab).toBeVisible();
            await propertiesViewer.additionalInfoTab.click();

            await expect.soft(propertiesViewer.createdDate).toContainText(currentDate);
            await expect.soft(propertiesViewer.lastModifiedDate).toContainText(currentDate);
            await expect.soft(propertiesViewer.docCreator).toContainText(currentUser);
            await expect.soft(propertiesViewer.lastContributor).toContainText(currentUser);
            await expect.soft(propertiesViewer.docContributors).toContainText(currentUser);
            await expect.soft(propertiesViewer.docSize).toContainText(fileSize);
            await expect.soft(propertiesViewer.mimeType).toContainText(pdfFile.mimeType);
            await expect(propertiesViewer.docPath).toContainText(path);
        });
    });

    test(`[C698840-OLD] Correct metadata is visible in the document viewer info panel`, async ({
        contentBrowserPage,
        hxprApi,
        skipOrExecuteTestBasedOnFlagStatus,
    }) => {
        await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.CicWorkspaceNewMetadataPanel, 'old-functionality');

        const { pdfFile } = files;
        const fileSize = '13.02 KB';
        const currentDate = format(new Date(), 'MMM d, yyyy');
        const fileCategory = 'SysFile';
        const { legacyPropertiesViewer } = contentBrowserPage.documentViewer;

        const uploadedFile = await hxprApi.uploadServiceApi.uploadFile(pdfFile, parentFolder.sys_id);

        const { firstName, lastName } = uploadedFile.sys_creator;
        const currentUser = `${firstName} ${lastName}`;
        const path = uploadedFile.sys_path;

        await contentBrowserPage.navigateToDocument(uploadedFile.sys_id);
        await contentBrowserPage.documentViewer.infoButton.click();

        await expect(legacyPropertiesViewer.getChild('')).toBeVisible();
        await expect.soft(legacyPropertiesViewer.categoryValue).toContainText(fileCategory); // wait for category to load

        const allProperties = await legacyPropertiesViewer.getAllProperties();
        const expectedProperties = {
            Title: uploadedFile.sys_title,
            Category: fileCategory,
            Created: currentDate,
            'Last Modified': currentDate,
            Creator: currentUser,
            'Last Contributor': currentUser,
            Filename: pdfFile.title,
            'Mime Type': pdfFile.mimeType,
            Size: fileSize,
            Contributors: currentUser,
            Path: path,
        };

        expect.soft(Object.keys(allProperties)).toEqual(Object.keys(expectedProperties)); // assert keys order
        expect(allProperties).toEqual(expectedProperties);
    });
});
