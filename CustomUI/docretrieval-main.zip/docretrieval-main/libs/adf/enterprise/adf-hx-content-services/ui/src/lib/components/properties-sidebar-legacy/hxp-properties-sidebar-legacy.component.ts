/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { CardViewItem, InfoDrawerComponent, InfoDrawerContentDirective, InfoDrawerLayoutComponent, InfoDrawerTabComponent } from '@alfresco/adf-core';
import { Component, DestroyRef, EventEmitter, inject, Inject, Input, OnChanges, Output, ViewEncapsulation } from '@angular/core';
import { DocumentService, DOCUMENT_PROPERTIES_SERVICE, SharedDocumentPropertiesService } from '@alfresco/adf-hx-content-services/services';
import { Observable } from 'rxjs';
import { take, finalize, filter } from 'rxjs/operators';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { NgIf, AsyncPipe } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { TranslatePipe } from '@ngx-translate/core';
import { PropertiesViewerContentComponent } from '../properties-viewer-content/properties-viewer-content.component';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { FeaturesServiceToken } from '@alfresco/adf-core/feature-flags';
import { ADF_HX_CONTENT_SERVICES_INTERNAL } from '@alfresco/adf-hx-content-services/features';

/**
 * Sidebar component to display and edit a Document properties.
 *
 * To use the `HxpPropertiesSidebarLegacyComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpPropertiesSidebarLegacyComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         HxpPropertiesSidebarLegacyComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 *
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-properties-sidebar-legacy [editable]="false" [document]="document" (closePropertySidebar)="onClose()">
 */
@Component({
    selector: 'hxp-properties-sidebar-legacy',
    templateUrl: './hxp-properties-sidebar-legacy.component.html',
    styleUrls: ['./hxp-properties-sidebar-legacy.component.scss'],
    encapsulation: ViewEncapsulation.None,
    standalone: true,
    imports: [
        InfoDrawerLayoutComponent,
        InfoDrawerContentDirective,
        MatButtonModule,
        MatIconModule,
        InfoDrawerComponent,
        InfoDrawerTabComponent,
        NgIf,
        MatProgressSpinnerModule,
        PropertiesViewerContentComponent,
        AsyncPipe,
        TranslatePipe,
    ],
})
export class HxpPropertiesSidebarLegacyComponent implements OnChanges {
    private readonly destroyRef = inject(DestroyRef);

    /**
     * The document to display the properties for
     * @type {Document}
     */
    @Input() document?: Document;

    /**
     * Input property to enable or disable edit mode availability
     * @type {boolean}
     * @default true
     */
    @Input() editable = true;

    /**
     * Emits an event when the sidebar is closed
     */
    @Output() closePropertySidebar = new EventEmitter<void>();

    protected propertyLoading = false;
    protected selectedDocument!: Document;
    protected documentProperties$!: Observable<CardViewItem[]>;
    protected otherDocumentProperties$!: Observable<CardViewItem[]>;
    protected readonly featuresService = inject(FeaturesServiceToken);
    protected readonly isMetadataPanelFeatureFlagOn = toSignal(
        this.featuresService.isOn$(ADF_HX_CONTENT_SERVICES_INTERNAL.CIC_WORKSPACE_NEW_METADATA_PANEL)
    );

    constructor(
        private readonly documentService: DocumentService,
        @Inject(DOCUMENT_PROPERTIES_SERVICE) private readonly documentPropertiesService: SharedDocumentPropertiesService
    ) {
        this.subscribeToDocumentUpdates();
    }

    ngOnChanges() {
        this.loadDocumentProperties(this.document?.sys_id ?? '');
    }

    protected handlePropertyUpdate(propertyUpdated: boolean): void {
        if (propertyUpdated) {
            this.fetchDefaultProperties();
            this.fetchOtherProperties();
        }
    }

    protected onClose(): void {
        this.closePropertySidebar.emit();
    }

    private subscribeToDocumentUpdates(): void {
        this.documentService.documentUpdated$
            .pipe(
                filter(({ document }) => !!document && document.sys_id === this.document?.sys_id),
                takeUntilDestroyed(this.destroyRef)
            )
            .subscribe({
                next: () => {
                    this.loadDocumentProperties(this.document?.sys_id ?? '');
                },
                error: (error) => console.error(error),
            });
    }

    private loadDocumentProperties(documentId: string): void {
        if (!documentId) {
            return;
        }

        this.propertyLoading = true;
        this.documentService
            .getDocumentById(documentId)
            .pipe(
                take(1),
                finalize(() => (this.propertyLoading = false))
            )
            .subscribe({
                next: (doc) => {
                    this.selectedDocument = doc;
                    this.fetchDocumentProperties();
                },
                error: ({ error }) => {
                    console.error(error);
                },
            });
    }

    private fetchDocumentProperties(): void {
        if (!this.selectedDocument) {
            return;
        }

        this.documentPropertiesService
            .extractCustomSchemaFields(this.selectedDocument.sys_primaryType)
            .pipe(take(1))
            .subscribe({
                next: (schemaFields: Record<string, any>) => {
                    this.initializeDocumentWithSchema(schemaFields);
                },
                error: (error) => console.error(error),
            });

        this.fetchDefaultProperties();
        this.fetchOtherProperties();
    }

    private initializeDocumentWithSchema(schemaFields: Record<string, any>, currentDoc: Record<string, any> = this.selectedDocument): void {
        for (const fieldName of Object.keys(schemaFields)) {
            if (!currentDoc[fieldName]) {
                currentDoc[fieldName] = typeof schemaFields[fieldName] === 'object' ? {} : '';
            }
            if (typeof schemaFields[fieldName] === 'object') {
                this.initializeDocumentWithSchema(schemaFields[fieldName], currentDoc[fieldName]);
            }
        }
    }

    private fetchDefaultProperties(): void {
        this.documentProperties$ = this.documentPropertiesService.getDefaultPropertiesFromDocument(this.selectedDocument);
    }

    private fetchOtherProperties(): void {
        this.otherDocumentProperties$ = this.documentPropertiesService.getPropertiesFromDocument(this.selectedDocument, {
            exclude: {
                schemas: ['sysfile_blob', 'sys_', 'sysver_', 'sysgov_'],
            },
        });
    }
}
