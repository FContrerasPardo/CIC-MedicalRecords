/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

const healthCheck = require('./workspace-hxp-health-checks');
const fetchDynamicAppDetails = require('./fetch-dynamic-app-details');

/**
 * Combined pre-e2e script that runs health checks before fetching dynamic app details
 * @param {string} projectName - The project name for dynamic app details
 */
module.exports = async (projectName) => {
    try {
        const currentProject = process.env.NX_TASK_TARGET_PROJECT;
        await healthCheck(currentProject);
        await fetchDynamicAppDetails(projectName);
    } catch (error) {
        console.error('❌ Pree2e setup failed:', error.message);
        process.exit(1);
    }
};
