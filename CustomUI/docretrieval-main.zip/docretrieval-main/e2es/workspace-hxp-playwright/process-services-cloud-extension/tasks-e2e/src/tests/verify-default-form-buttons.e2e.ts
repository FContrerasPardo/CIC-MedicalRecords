/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { getUserState, ProcessInstanceDataEntry, HXP_APPS } from '@alfresco-dbp/playwright/shared';
import { test, expect } from '@hxp/playwright/workspace-hxp';

test.use({ storageState: getUserState('hruser') });
test.describe('Default form buttons', () => {
    const { hiddenFormButtons, modifiedFormButtons } = HXP_APPS.SYS_WORKSPACE.processes;
    let hiddenFormButtonsProcessInstance: ProcessInstanceDataEntry;
    let modifiedFormButtonsProcessInstance: ProcessInstanceDataEntry;

    test.afterAll(async ({ runtimeBundleServiceHrUser }) => {
        await runtimeBundleServiceHrUser.processInstance.deleteProcessesIfExist(
            hiddenFormButtonsProcessInstance?.id,
            modifiedFormButtonsProcessInstance?.id
        );
    });

    test(`[XAT-18260] Should not able to see hidden form buttons`, async ({ startProcessPage, taskDetailsPage, runtimeBundleServiceHrUser }) => {
        await test.step('Open Start Process page', async () => {
            await startProcessPage.navigate({ query: `?process=${hiddenFormButtons.processName}` });
            await startProcessPage.taskForm.waitForRootElement();
        });

        await test.step('Verify hidden form buttons are not visible', async () => {
            await expect.soft(startProcessPage.startProcessFooter.startProcessButton).toBeVisible();
            await expect.soft(startProcessPage.startProcessFooter.cancelProcessButton).toBeHidden();
        });

        await test.step('Start Process and Open Task', async () => {
            ({ entry: hiddenFormButtonsProcessInstance } = await runtimeBundleServiceHrUser.processInstance.startProcess(
                hiddenFormButtons.processDefinitionKey,
                {
                    name: hiddenFormButtons.processName,
                }
            ));

            const userTask = await runtimeBundleServiceHrUser.processInstance.waitAndGetTasksByProcessInstanceId(hiddenFormButtonsProcessInstance.id);
            await taskDetailsPage.navigate({ query: `/${userTask[0].entry.id}`, waitUntil: 'load' });
        });

        await test.step('Verify hidden form buttons are not visible', async () => {
            await expect.soft(taskDetailsPage.taskForm.completeButtonLocator).toBeVisible();
            await expect.soft(taskDetailsPage.taskForm.cancelButtonLocator).toBeHidden();
            await expect(taskDetailsPage.taskForm.saveButtonLocator).toBeHidden();
        });
    });

    test(`Default form buttons should display configured text`, async ({ startProcessPage, taskDetailsPage, runtimeBundleServiceHrUser }) => {
        await test.step('Open Start Process page', async () => {
            await startProcessPage.navigate({ query: `?process=${modifiedFormButtons.processName}` });
            await startProcessPage.taskForm.waitForRootElement();
        });

        await test.step('Verify modified form buttons text', async () => {
            await expect(startProcessPage.startProcessFooter.startProcessButton).toContainText('modified-start-process');
            await expect(startProcessPage.startProcessFooter.cancelProcessButton).toContainText('modified-cancel');
        });

        await test.step('Start Process and Open Task', async () => {
            ({ entry: modifiedFormButtonsProcessInstance } = await runtimeBundleServiceHrUser.processInstance.startProcess(
                modifiedFormButtons.processDefinitionKey,
                {
                    name: modifiedFormButtons.processName,
                }
            ));

            const userTask = await runtimeBundleServiceHrUser.processInstance.waitAndGetTasksByProcessInstanceId(
                modifiedFormButtonsProcessInstance.id
            );
            await taskDetailsPage.navigate({ query: `/${userTask[0].entry.id}`, waitUntil: 'load' });
        });

        await test.step('Verify modified buttons are visible', async () => {
            await expect.soft(taskDetailsPage.taskForm.completeButtonLocator).toContainText('modified-complete');
            await expect.soft(taskDetailsPage.taskForm.cancelButtonLocator).toContainText('modified-cancel');
            await expect(taskDetailsPage.taskForm.saveButtonLocator).toContainText('modified-save');
        });
    });
});
