/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { getUserState, UtilRandom, files, TestFlags } from '@alfresco-dbp/playwright/shared';
import { expect, test, WorkspaceHxpFeatureFlagNames } from '@hxp/playwright/workspace-hxp';
import { Document } from '@hylandsoftware/hxcs-js-client';

let parentFolder: Document;
let uploadedFile: Document;
let updatedFileTitle: string;

test.use({ storageState: getUserState('hruser') });

test.beforeEach(async ({ hxprApi, contentBrowserPage }) => {
    parentFolder = await hxprApi.documentServiceApi.createFolderWithPermissions('File Management', 'edit-properties', 'hr');
    uploadedFile = await hxprApi.uploadServiceApi.uploadFile(files.pdfFile, parentFolder.sys_id);
    updatedFileTitle = `e2e--${UtilRandom.generateAlphaNumeric(8)}.pdf`;

    await contentBrowserPage.navigateToDocument(parentFolder.sys_id);
});

test.afterEach(async ({ hxprApi }) => hxprApi.documentServiceApi.teardown());

test.describe('Edit File Properties', async () => {
    test(`[C698871] User should be able to edit Main properties of a File`, async ({ contentBrowserPage, skipOrExecuteTestBasedOnFlagStatus }) => {
        await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.CicWorkspaceNewMetadataPanel, 'old-functionality');

        await contentBrowserPage.mainContentContainer.getDocByTestId(uploadedFile.sys_title).click();
        await contentBrowserPage.documentViewer.infoButton.click();
        await contentBrowserPage.documentViewer.legacyPropertiesViewer.editTitle(updatedFileTitle);
        await contentBrowserPage.documentViewer.legacyPropertiesViewer.saveButton.click();
        await contentBrowserPage.navigateToDocument(parentFolder.sys_id);

        await expect(contentBrowserPage.mainContentContainer.getDocByTestId(updatedFileTitle)).toBeVisible();
    });

    test(`[C698872] User should be able to cancel editing Main properties of a File`, async ({
        contentBrowserPage,
        skipOrExecuteTestBasedOnFlagStatus,
    }) => {
        await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.CicWorkspaceNewMetadataPanel, 'old-functionality');

        await contentBrowserPage.mainContentContainer.getDocByTestId(uploadedFile.sys_title).click();
        await contentBrowserPage.documentViewer.infoButton.click();
        await contentBrowserPage.documentViewer.legacyPropertiesViewer.editTitle(updatedFileTitle);
        await contentBrowserPage.documentViewer.legacyPropertiesViewer.cancelButton.click();
        await contentBrowserPage.navigateToDocument(parentFolder.sys_id);

        await expect(contentBrowserPage.mainContentContainer.getDocByTestId(uploadedFile.sys_title)).toBeVisible();
    });
});

test.describe('New Edit File Properties', async () => {
    test(`${TestFlags.UnderFF} [XAT-446] User should be able to edit the main properties of a document`, async ({
        contentBrowserPage,
        skipOrExecuteTestBasedOnFlagStatus,
    }) => {
        await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.CicWorkspaceNewMetadataPanel, 'new-functionality');
        const { propertiesViewer } = contentBrowserPage.documentViewer;
        await contentBrowserPage.performToolbarAction(uploadedFile.sys_title, 'Info');

        await test.step('Save new file name via save button', async () => {
            await propertiesViewer.editFileName(updatedFileTitle);
            await propertiesViewer.saveButton.click();

            await expect.soft(propertiesViewer.editButton).toBeVisible();
            await expect.soft(propertiesViewer.fileNameField).toHaveValue(updatedFileTitle);
        });

        await test.step('Save new title via confirmation dialog', async () => {
            await propertiesViewer.editTitle(updatedFileTitle);
            await propertiesViewer.cancelButton.click();
            await propertiesViewer.confirmationDialog.saveButton.click();

            await expect.soft(propertiesViewer.editButton).toBeVisible();
            await expect.soft(propertiesViewer.titleField).toHaveValue(updatedFileTitle);
            await expect.soft(contentBrowserPage.mainContentContainer.getDocByTestId(updatedFileTitle)).toBeVisible();
            await expect.soft(contentBrowserPage.mainContentContainer.getDocByTestId(uploadedFile.sys_title)).not.toBeVisible();
        });
    });

    test(`${TestFlags.UnderFF} [XAT-445] User should be able to cancel editing the main properties of a document`, async ({
        contentBrowserPage,
        skipOrExecuteTestBasedOnFlagStatus,
    }) => {
        await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.CicWorkspaceNewMetadataPanel, 'new-functionality');
        const { propertiesViewer } = contentBrowserPage.documentViewer;
        await contentBrowserPage.performToolbarAction(uploadedFile.sys_title, 'Info');

        await test.step('Cancel without making any changes', async () => {
            await propertiesViewer.editButton.click();
            await propertiesViewer.cancelButton.click();

            await expect.soft(propertiesViewer.confirmationDialog.getChild('')).not.toBeVisible();
            await expect.soft(propertiesViewer.editButton).toBeVisible();
        });

        await test.step('Cancel editing then click "Continue Editing" in the dialog', async () => {
            await propertiesViewer.editTitle(updatedFileTitle);
            await propertiesViewer.cancelButton.click();

            await expect(propertiesViewer.confirmationDialog.getChild('')).toBeVisible();

            await propertiesViewer.confirmationDialog.continueEditingButton.click();

            await expect.soft(propertiesViewer.confirmationDialog.getChild('')).not.toBeVisible();
            await expect.soft(propertiesViewer.cancelButton).toBeVisible();
        });

        await test.step('Try closing the sidebar then click "Discard Changes" in the dialog', async () => {
            await propertiesViewer.closeButton.click();

            await expect(propertiesViewer.confirmationDialog.getChild('')).toBeVisible();

            await propertiesViewer.confirmationDialog.discardButton.click();

            await expect.soft(propertiesViewer.editButton).toBeVisible();
            await expect.soft(contentBrowserPage.mainContentContainer.getDocByTestId(uploadedFile.sys_title)).toBeVisible();
            await expect.soft(contentBrowserPage.mainContentContainer.getDocByTestId(updatedFileTitle)).not.toBeVisible();
        });
    });
});
