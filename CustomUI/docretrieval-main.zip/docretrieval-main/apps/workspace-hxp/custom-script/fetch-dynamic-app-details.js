/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

const axios = require('axios');
const { getAuthToken } = require('../../../scripts/utils/get-auth-token');
const { handleError } = require('../../../scripts/utils/axios-error-handler');

module.exports = async (projectName) => {
    console.log('🔎 Fetching dynamic app details for', projectName);
    const domain = process.env['APP_CONFIG_BPM_HOST'];
    const config = {
        clientId: process.env['APP_CONFIG_OAUTH2_CLIENTID_ADMIN'],
        clientSecret: process.env['APP_CONFIG_OAUTH2_SECRET_ADMIN'],
        username: process.env['DEVOPS_EMAIL'],
        password: process.env['DEVOPS_PASSWORD'],
    };

    const tokenDevops = await getAuthToken(config);

    const filterDescriptors = (applications, appName) => {
        const envId = (process.env['APP_CONFIG_ENVIRONMENT_ID'] || '').split('-');
        const fullAppName = envId ? appName + '-' + envId[0] : appName;
        const deployedApp = applications.find((app) => app.entry.name.indexOf(fullAppName) === 0);
        return deployedApp.entry;
    };

    const isApplicationDeployed = async (appName) => {
        try {
            const res = await axios.get(`${domain}/deployment-service/v1/applications?page=0&size=50&sort=createdAt,desc&name=${appName}`, {
                headers: {
                    Authorization: `Bearer ${tokenDevops}`,
                },
            });
            const applications = res.data.list.entries;
            if (applications.length > 0) {
                const app = filterDescriptors(applications, appName);
                if (app.status === 'Deployed') {
                    console.log(`... ✅ Application ${appName} is deployed`);
                    return true;
                } else {
                    if (app.status !== 'Deployed') {
                        console.log(`... ⏳ Application ${appName} is in an intermediate state "${app.status}"`);
                        return false;
                    }
                }
            } else if (applications.length > 1) {
                console.log(`⚠️ It looks like there are multiple applications with the same name. Please clean it up and try again.`);
                process.exit(1);
            }
            return false;
        } catch (error) {
            console.error(`❌ Error fetching deployed applications:`);
            handleError(error);
            return false;
        }
    };

    const getApplicationDescriptor = async (appName) => {
        try {
            const res = await request(`deployment-service/v1/applications?page=0&size=50&sort=createdAt,desc&name=${appName}`);
            const applications = res.data.list.entries;
            if (applications.length > 0) {
                const app = filterDescriptors(applications, appName);
                if (app.status === 'Deployed') {
                    return app.descriptor;
                }
                if (app.status === 'DeploymentIncomplete' || app.status === 'Deploying') {
                    console.log(`⏱️ App is in '${app.status}' status. Waiting for the app to be deployed`);
                    let i = 5;
                    do {
                        await new Promise((r) => setTimeout(r, 60000));
                        console.log(`... 🔎 Checking if the app ${appName} is deployed... ${i} minutes left`);
                    } while (!(await isApplicationDeployed(appName)) && --i > 0);

                    if (i === 0) {
                        console.log(`... ❌ App ${appName} is not deployed after ${i} minutes. Please check the logs.`);
                        process.exit(1);
                    } else {
                        console.log(`✅ App ${appName} deployed successfully`);
                        return app.descriptor;
                    }
                }
            }
            handleError({
                message: `${appName} is missing or not deployed\nResponse data: ${JSON.stringify(res.data, null, 2)}`,
            });
            return false;
        } catch (error) {
            console.error(`❌ Error fetching deployed applications:`);
            handleError(error);
            return false;
        }
    };

    const getApplicationVariables = async (appInstanceName) => {
        try {
            const res = await request(`deployment-service/v1/applications/${appInstanceName}/variables/ui`);
            console.log('🔎 getApplicationVariables', res.data);
            if (res.data) {
                return res.data;
            }
            handleError({
                message: `${appInstanceName} is missing or not deployed\nResponse data: ${JSON.stringify(res.data, null, 2)}`,
            });
            return false;
        } catch (error) {
            console.error(`❌ Error fetching application variables:`);
            handleError(error, true);
            return false;
        }
    };

    const request = async (url) => {
        return await axios.get(`${domain}/${url}`, {
            headers: {
                Authorization: `Bearer ${tokenDevops}`,
            },
        });
    };

    const { name } = await getApplicationDescriptor(projectName);
    const { APP_CONFIG_APPS_DEPLOYED, APP_CONFIG_OAUTH2_SCOPE, APP_CONFIG_ECM_HOST, APP_CONFIG_OAUTH2_CLIENTID } = await getApplicationVariables(
        name
    );

    console.log('ℹ️ Configure CI to refer default deployed app');
    process.env['APP_CONFIG_APPS_DEPLOYED'] = APP_CONFIG_APPS_DEPLOYED;
    process.env['APP_CONFIG_OAUTH2_SCOPE'] = APP_CONFIG_OAUTH2_SCOPE;
    process.env['APP_CONFIG_ECM_HOST'] = APP_CONFIG_ECM_HOST;
    process.env['APP_CONFIG_OAUTH2_CLIENTID'] = APP_CONFIG_OAUTH2_CLIENTID;
};
