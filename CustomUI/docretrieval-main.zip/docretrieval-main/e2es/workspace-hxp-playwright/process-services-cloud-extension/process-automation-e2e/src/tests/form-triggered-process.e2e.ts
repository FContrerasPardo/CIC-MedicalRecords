/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { HXP_APPS, getUserState, timeouts } from '@alfresco-dbp/playwright/shared';
import { test, expect } from '@hxp/playwright/workspace-hxp';

test.describe('Async form process', () => {
    test.use({ storageState: getUserState('hruser') });

    test.beforeEach(async ({ processDetailsPage }, workerInfo) => {
        await processDetailsPage.refreshUserState('hruser', workerInfo.project.use);
    });

    const { processWithFormRules, asyncTestProcess } = HXP_APPS.SYS_WORKSPACE.processes;

    test('[XAT-18133] Should be able to start process with onFormLoaded event and display results', async ({ startProcessPage }) => {
        const { textInputId, integerInputId, dateInputId, datetimeInputId, checkboxInputId } = processWithFormRules.form.formWidgets;
        const { textVar, integerVar, dateVar, dateTimeVar } = asyncTestProcess.variables;

        const textInputLocator = startProcessPage.taskForm.getFieldInputByIdLocator(textInputId);
        const integerInputLocator = startProcessPage.taskForm.getFieldInputByIdLocator(integerInputId);
        const dateInputLocator = startProcessPage.taskForm.getFieldInputByIdLocator(dateInputId);
        const dateTimeInputLocator = startProcessPage.taskForm.getFieldInputByIdLocator(datetimeInputId);
        const booleanInputLocator = startProcessPage.taskForm.getFieldInputByIdLocator(checkboxInputId);

        await test.step('Open the start process form', async () => {
            await startProcessPage.navigate({ query: `?process=${processWithFormRules.processName}` });
            await textInputLocator.waitFor();
        });

        await test.step('Verify if form fields are updated', async () => {
            await startProcessPage.page.waitForTimeout(timeouts.medium);

            await test.step('Localise and compare dates, as this test fails when executed locally without this step', async () => {
                const actualDateTimeValue = await dateTimeInputLocator.inputValue();
                const actualDateTimeFormatted = new Date(actualDateTimeValue);
                const expectedDateTimeUTC = new Date(dateTimeVar.value + ':00Z');

                expect.soft(actualDateTimeFormatted).toStrictEqual(expectedDateTimeUTC);
            });

            await expect.soft(textInputLocator).toHaveValue(textVar.value);
            await expect.soft(integerInputLocator).toHaveValue(integerVar.value);
            await expect.soft(dateInputLocator).toHaveValue(dateVar.value);
            expect(booleanInputLocator.isChecked()).toBeTruthy();
        });
    });
});
