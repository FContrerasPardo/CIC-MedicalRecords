/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { HXP_APPS, getUserState, ProcessInstanceDataEntry } from '@alfresco-dbp/playwright/shared';
import { test, expect } from '@hxp/playwright/workspace-hxp';

test.use({ storageState: getUserState('hruser') });
test.describe('Visual Regression - Workspace Form View', () => {
    const { processes } = HXP_APPS.SYS_WORKSPACE;
    const { vrScholarshipFormProcess } = processes;
    let processInstance: ProcessInstanceDataEntry;

    test.beforeEach(async ({ processDetailsPage, taskDetailsPage, runtimeBundleServiceHrUser }, workerInfo) => {
        await processDetailsPage.refreshUserState('hruser', workerInfo.project.use);
        ({ entry: processInstance } = await runtimeBundleServiceHrUser.processInstance.startProcess(vrScholarshipFormProcess.processDefinitionKey));

        const userTask = await runtimeBundleServiceHrUser.processInstance.waitAndGetTasksByProcessInstanceId(processInstance.id);
        await taskDetailsPage.navigate({ query: `/${userTask[0].entry.id}`, waitUntil: 'load' });
        await taskDetailsPage.taskForm.formContainerLocator.waitFor({ state: 'visible' });
        await taskDetailsPage.taskForm.peopleWidgetProgressBarLocator.waitFor({ state: 'hidden' });
    });

    test.afterEach(async ({ runtimeBundleServiceHrUser }) => {
        await runtimeBundleServiceHrUser.processInstance.deleteProcessesIfExist(processInstance.id);
    });

    test('[XAT-18517] Should display form correctly in workspace', async ({ taskDetailsPage }) => {
        await test.step('Validate full screen scholarship form appearance', async () => {
            await expect.soft(taskDetailsPage.page).toHaveScreenshot('XAT-18517-scholarship-form.png', {
                fullPage: true,
            });
        });
        await test.step('Validate widgets containers appearance', async () => {
            for (const widgetId of Object.values(vrScholarshipFormProcess.form.formWidgets)) {
                const widgetContainer = taskDetailsPage.taskForm.getWidgetContainerLocator(widgetId);
                await widgetContainer.scrollIntoViewIfNeeded();

                await expect.soft(widgetContainer).toHaveScreenshot(`XAT-18517-${widgetId}.png`);
            }
        });
        await test.step('Validate scrolled down full screen scholarship form appearance', async () => {
            await taskDetailsPage.taskForm.scrollContainerToBottom(taskDetailsPage.taskForm.formContainerLocator);

            await expect(taskDetailsPage.page).toHaveScreenshot('XAT-18517-scholarship-form-scrolled.png', {
                fullPage: true,
            });
        });
    });
});
