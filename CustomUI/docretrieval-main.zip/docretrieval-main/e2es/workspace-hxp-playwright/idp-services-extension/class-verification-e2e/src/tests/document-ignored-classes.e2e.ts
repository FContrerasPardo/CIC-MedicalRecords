/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { ProcessInstanceData, RequestResponse, getUserState } from '@alfresco-dbp/playwright/shared';
import { test, expect, idpHelperMethods, IdpBatchStateSnapshotRunner } from '@hxp/playwright/workspace-hxp';
import { BATCH_STATE_SNAPSHOTS } from '../resources';

const { waitForUserTask, refreshUserState } = idpHelperMethods;

test.use({ storageState: getUserState('hruser') });

test.describe('Workspace IDP - Ignored classes behavior in class verification', () => {
    let processInstance: ProcessInstanceData | RequestResponse | undefined;
    let batchRunner: IdpBatchStateSnapshotRunner;

    test.beforeAll(async ({ idpBatchStateSnapshotInitializer }) => {
        batchRunner = await idpBatchStateSnapshotInitializer.upload(BATCH_STATE_SNAPSHOTS.twoInvoices);
    });

    test.beforeEach(async ({ tasksPage }, workerInfo) => {
        await refreshUserState(tasksPage, workerInfo);
    });

    test.afterEach(async ({ runtimeBundleServiceHrUser: runtimeBundleService }) => {
        await runtimeBundleService.processInstance.deleteProcessesIfExist(processInstance?.entry?.id);
        processInstance = undefined;
    });

    test(`[XAT-18422] Should display lock icon for class ignored for auto-classification (Loan Application (IGNORED_CLASS) if present)`, async ({
        taskDetailsPage,
        runtimeBundleServiceHrUser: runtimeBundleService,
        idpClassificationPage,
    }) => {
        await test.step('Start the processes', async () => {
            processInstance = await batchRunner.startProcess(runtimeBundleService);
            const userTasks = await waitForUserTask(runtimeBundleService, processInstance);
            await taskDetailsPage.navigate({ query: `/${userTasks[0].entry.id}`, waitUntil: 'load' });
        });

        await test.step('Verify lock icon is displayed', async () => {
            const className = 'Loan Application (IGNORED_CLASS)';
            await idpClassificationPage.documentBrowser.sortByOption.click();
            await idpClassificationPage.overlayContainer.sortOption1.click();

            const classNameLocator = idpClassificationPage.page.locator('[data-automation-id="idp-class-name"]', { hasText: className });
            await expect(classNameLocator).toBeVisible();

            const lockIconLocator = idpClassificationPage.page.locator(
                `.idp-ignored-class-icon:near([data-automation-id="idp-class-name"]:has-text("${className}"))`
            );

            await expect(lockIconLocator).toBeVisible();
        });

        await test.step('Verify class is not listed', async () => {
            const classNameLocator = idpClassificationPage.page.locator('[data-automation-id="idp-class-name"]', {
                hasText: 'HIDDEN CLASS (HIDE_FOR_REVIEW)',
            });
            await expect.soft(classNameLocator).toHaveCount(0);
        });
    });

    test(`[XAT-18423] Should allow manual assignment to an auto-ignored class`, async ({
        taskDetailsPage,
        runtimeBundleServiceHrUser: runtimeBundleService,
        idpClassificationPage,
    }) => {
        const ignoredClassName = 'Loan Application (IGNORED_CLASS)';

        await test.step('Start the processes', async () => {
            processInstance = await batchRunner.startProcess(runtimeBundleService);
            const userTasks = await waitForUserTask(runtimeBundleService, processInstance);
            await taskDetailsPage.navigate({ query: `/${userTasks[0].entry.id}`, waitUntil: 'load' });
        });

        await test.step('Open Change Class, select ignored class, and submit', async () => {
            await idpClassificationPage.documentBrowser.sortByOption.click();
            await idpClassificationPage.overlayContainer.sortOption1.click();
            await idpClassificationPage.floaterToolbar.changeClassButton.click();

            await idpClassificationPage.changeClassDialog.classSearchField.fill(ignoredClassName);
            const optionLocator = idpClassificationPage.page.locator('[data-automation-id^="idp-dialog-list-item-"]', {
                hasText: ignoredClassName,
            });
            await optionLocator.first().click();
            await idpClassificationPage.changeClassDialog.submitChangeButton.click();
        });

        await test.step('Verify document now appears under the ignored class', async () => {
            const classNameLocator = idpClassificationPage.page.locator('[data-automation-id="idp-class-name"]', { hasText: ignoredClassName });
            await expect(classNameLocator).toBeVisible();
            await expect(classNameLocator).toBeEnabled();
        });
    });
});
