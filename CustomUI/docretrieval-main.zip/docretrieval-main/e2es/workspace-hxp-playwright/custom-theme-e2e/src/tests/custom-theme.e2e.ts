/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { getUserState, HXP_APPS, TestFlags } from '@alfresco-dbp/playwright/shared';
import { test, expect, ProcessManagementLabels, WorkspaceHxpFeatureFlagNames } from '@hxp/playwright/workspace-hxp';

test.describe('Custom theme', () => {
    const { customTheme } = HXP_APPS.SYS_WORKSPACE;
    test.use({ storageState: getUserState('hruser') });

    test(
        `[C688002] Should be able to apply custom theme`,
        { tag: [TestFlags.UnderFF] },
        async ({ skipOrExecuteTestBasedOnFlagStatus, processPage, contentBrowserPage }) => {
            await skipOrExecuteTestBasedOnFlagStatus(test, WorkspaceHxpFeatureFlagNames.CicWorkspaceSatoriApplicationChrome, 'new-functionality');
            await processPage.navigate();
            await processPage.dataTable.waitForRootElement();

            await test.step('Validate if the Application name for custom ui comes from the config', async () => {
                await expect.soft(contentBrowserPage.satoriHeaderComponent.appHeaderTitle).toHaveText('Custom Theme Testing');
            });

            await test.step('Validate CSS for the content side nav bar', async () => {
                await expect.soft(processPage.pageLayoutHeaderComponent.startProcessButton).toHaveCSS('background-color', customTheme.primaryColor);

                await contentBrowserPage.contentSideNavbar.getSidenavItemLabelLocator(ProcessManagementLabels.MyTasks).click();

                await expect
                    .soft(contentBrowserPage.contentSideNavbar.getSidenavItemLabelLocator(ProcessManagementLabels.MyTasks))
                    .toHaveCSS('color', customTheme.textColor);
                await expect
                    .soft(contentBrowserPage.contentSideNavbar.getSidenavItemLabelLocator(ProcessManagementLabels.QueuedTasks))
                    .toHaveCSS('color', customTheme.textColor);

                await expect.soft(contentBrowserPage.contentSideNavbar.getRootLocator).toHaveCSS('background-color', customTheme.backgroundColor);
                await expect.soft(contentBrowserPage.contentSideNavbar.getRootLocator).toHaveCSS('color', customTheme.textColor);

                await expect.soft(await processPage.contentSideNavbar.getBody()).toHaveCSS('font-size', customTheme.fontSize);
                await expect.soft(await processPage.contentSideNavbar.getBody()).toHaveCSS('font-family', customTheme.fontFamily);
            });

            await test.step('Validate CSS for the header component', async () => {
                await expect.soft(contentBrowserPage.satoriHeaderComponent.appHeaderLogo).toHaveAttribute('src', customTheme.logoImage);
                await expect.soft(contentBrowserPage.satoriHeaderComponent.appHeaderTitle).toHaveCSS('color', customTheme.headerTextColor);

                const expectedAttributes = {
                    headerBg: `--hxp-header-bg: ${customTheme.headerColor};`,
                    headerBgImage: `--hxp-header-bg-image: ${customTheme.backgroundImageUrl};`,
                    headerTextColor: `--hxp-header-text-color: ${customTheme.headerTextColorHex};`,
                };

                await expect(contentBrowserPage.hxpWorkspaceHeaderComponent.getAppHeaderContainerLocator).toHaveAttribute(
                    'style',
                    `${expectedAttributes.headerBg} ${expectedAttributes.headerBgImage} ${expectedAttributes.headerTextColor}`
                );
            });
        }
    );
});
